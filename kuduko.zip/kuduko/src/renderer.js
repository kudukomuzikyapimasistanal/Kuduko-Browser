const path = require('path');
const { pathToFileURL } = require('url');
const { ipcRenderer } = require('electron');

/* ================= Sabitler & yardımcılar ================= */
const HOME = pathToFileURL(path.join(__dirname, 'home.html')).href;
const SEARCH = pathToFileURL(path.join(__dirname, 'search.html')).href;
const ERROR = pathToFileURL(path.join(__dirname, 'error.html')).href;
const DOWNLOADS = pathToFileURL(path.join(__dirname, 'downloads.html')).href;
const PRELOAD = pathToFileURL(path.join(__dirname, 'preload.js')).href;
const qs = new URLSearchParams(location.search);
const PRIVATE = qs.get('private') === '1';
const PARTITION = PRIVATE ? 'private-' + (qs.get('p') || Date.now()) : null;
if (PRIVATE) document.body.classList.add('private');
// ---- Kuduko hesaplar, arka plan ve ayarlar (web ve masaüstü sürümlerinde ortak) ----
const ACCT = (() => {
  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  const GP = 'kuduko.g.';
  const G = {
    get(k, d) { try { const v = localStorage.getItem(GP + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(GP + k, JSON.stringify(v)); } catch (e) { } },
    del(k) { try { localStorage.removeItem(GP + k); } catch (e) { } }
  };
  const enabled = !PRIVATE;
  const COLORS = ['#2f6bff', '#e8453c', '#1fa463', '#f5b400', '#b15cff', '#e8742c', '#14a7b8'];
  let users = enabled ? G.get('users', []) : [];
  let cur = null;
  (function () {
    if (!enabled) return;
    let s = null;
    try { s = JSON.parse(sessionStorage.getItem('kuduko.session') || 'null'); } catch (e) { }
    if (!s) s = G.get('session', null);
    if (s) cur = users.find(u => u.id === s.uid) || null;
  })();
  const listeners = [];
  const b64 = u => btoa(String.fromCharCode.apply(null, Array.from(u)));
  const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const canCrypto = () => !!(window.crypto && crypto.subtle);
  async function hash(pass, salt, iter) {
    const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveBits']);
    return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, km, 256));
  }
  const same = (a, b) => { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i]; return d === 0; };
  function saveSession(u, remember) {
    try { sessionStorage.removeItem('kuduko.session'); } catch (e) { }
    G.del('session');
    if (!u) return;
    if (remember) G.set('session', { uid: u.id });
    else { try { sessionStorage.setItem('kuduko.session', JSON.stringify({ uid: u.id })); } catch (e) { } }
  }
  function setCur(u, remember) { cur = u; saveSession(u, remember); listeners.forEach(f => f(cur)); }
  const NAME_RE = /^[\p{L}\p{N}_.-]{3,24}$/u;
  async function register(o) {
    if (!enabled) return { error: 'InPrivate pencerede hesap kullanılamaz.' };
    if (!canCrypto()) return { error: 'Bu ortamda güvenli kayıt kullanılamıyor (https ya da localhost gerekir).' };
    const name = (o.name || '').trim(), email = (o.email || '').trim();
    if (!NAME_RE.test(name)) return { error: 'Kullanıcı adı 3-24 karakter olmalı (harf, rakam, _ . -).' };
    if (users.some(u => u.name.toLowerCase() === name.toLowerCase())) return { error: 'Bu kullanıcı adı alınmış.' };
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: 'E-posta adresi geçersiz.' };
    if (email && users.some(u => u.email && u.email.toLowerCase() === email.toLowerCase())) return { error: 'Bu e-posta ile zaten bir hesap var.' };
    if ((o.pass || '').length < 6) return { error: 'Parola en az 6 karakter olmalı.' };
    if (o.pass !== o.pass2) return { error: 'Parolalar eşleşmiyor.' };
    const salt = crypto.getRandomValues(new Uint8Array(16)), iter = 200000;
    const u = { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), name, email, salt: b64(salt), hash: b64(await hash(o.pass, salt, iter)), iter, color: COLORS[users.length % COLORS.length], created: Date.now() };
    users = users.concat([u]); G.set('users', users); setCur(u, !!o.remember);
    return { ok: true, user: u };
  }
  let fails = 0, lockUntil = 0;
  async function verify(u, pass) { return same(await hash(pass, unb64(u.salt), u.iter), unb64(u.hash)); }
  async function login(o) {
    if (!enabled) return { error: 'InPrivate pencerede hesap kullanılamaz.' };
    if (!canCrypto()) return { error: 'Bu ortamda güvenli giriş kullanılamıyor (https ya da localhost gerekir).' };
    if (Date.now() < lockUntil) return { error: 'Çok fazla hatalı deneme. ' + Math.ceil((lockUntil - Date.now()) / 1000) + ' sn sonra tekrar dene.' };
    const id = (o.id || '').trim().toLowerCase();
    const u = users.find(x => x.name.toLowerCase() === id || (x.email && x.email.toLowerCase() === id));
    const ok = u ? await verify(u, o.pass || '') : false;
    if (!ok) { fails++; if (fails >= 5) { lockUntil = Date.now() + 30000; fails = 0; } return { error: 'Kullanıcı adı ya da parola yanlış.' }; }
    fails = 0; setCur(u, !!o.remember); return { ok: true, user: u };
  }
  async function remove(pass) {
    if (!cur) return { error: 'Oturum açık değil.' };
    if (!(await verify(cur, pass || ''))) return { error: 'Parola yanlış.' };
    const id = cur.id, pre = 'kuduko.u.' + id + '.';
    try { Object.keys(localStorage).filter(k => k.indexOf(pre) === 0).forEach(k => localStorage.removeItem(k)); } catch (e) { }
    users = users.filter(u => u.id !== id); G.set('users', users);
    listeners.forEach(f => f({ removed: id }));
    setCur(null, false); return { ok: true, id };
  }
  const profileListeners = [];
  async function update(f) {
    if (!cur) return { error: 'Oturum açık değil.' };
    const n = Object.assign({}, cur);
    if (f.name != null) {
      const name = f.name.trim();
      if (!NAME_RE.test(name)) return { error: 'Kullanıcı adı 3-24 karakter olmalı (harf, rakam, _ . -).' };
      if (users.some(u => u.id !== cur.id && u.name.toLowerCase() === name.toLowerCase())) return { error: 'Bu kullanıcı adı alınmış.' };
      n.name = name;
    }
    if (f.email != null) {
      const email = f.email.trim();
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: 'E-posta adresi geçersiz.' };
      if (email && users.some(u => u.id !== cur.id && u.email && u.email.toLowerCase() === email.toLowerCase())) return { error: 'Bu e-posta ile başka bir hesap var.' };
      n.email = email;
    }
    if (f.displayName != null) { const d = f.displayName.trim(); if (d.length > 40) return { error: 'Görünen ad en fazla 40 karakter olabilir.' }; n.displayName = d; }
    if (f.photo !== undefined) n.photo = f.photo || '';
    users = users.map(u => u.id === cur.id ? n : u); G.set('users', users); cur = n;
    profileListeners.forEach(fn => fn(cur)); return { ok: true, user: n };
  }
  async function changePassword(oldP, newP, newP2) {
    if (!cur) return { error: 'Oturum açık değil.' };
    if (!canCrypto()) return { error: 'Bu ortamda güvenli işlem kullanılamıyor (https ya da localhost gerekir).' };
    if (!(await verify(cur, oldP || ''))) return { error: 'Eski parola yanlış.' };
    if ((newP || '').length < 6) return { error: 'Yeni parola en az 6 karakter olmalı.' };
    if (newP !== newP2) return { error: 'Yeni parolalar eşleşmiyor.' };
    const salt = crypto.getRandomValues(new Uint8Array(16)), iter = 200000;
    const n = Object.assign({}, cur, { salt: b64(salt), hash: b64(await hash(newP, salt, iter)), iter });
    users = users.map(u => u.id === cur.id ? n : u); G.set('users', users); cur = n; return { ok: true };
  }
  function loadImg(file) {
    return new Promise((res, rej) => { const u = URL.createObjectURL(file), im = new Image(); im.onload = () => { URL.revokeObjectURL(u); res(im); }; im.onerror = () => { URL.revokeObjectURL(u); rej(new Error('Resim okunamadı.')); }; im.src = u; });
  }
  // Seçilen fotoğrafı ortadan kare keser, 256 px'e küçültür
  async function photoFromFile(file) {
    if (!file || !/^image\//.test(file.type)) throw new Error('Lütfen bir resim dosyası seç (JPG, PNG, WebP…).');
    if (file.size > 15 * 1024 * 1024) throw new Error('Dosya çok büyük (en fazla 15 MB).');
    let src; try { src = await createImageBitmap(file); } catch (e) { src = await loadImg(file); }
    const w = src.width || src.naturalWidth, h = src.height || src.naturalHeight, side = Math.min(w, h);
    const c = document.createElement('canvas'); c.width = c.height = 256;
    c.getContext('2d').drawImage(src, (w - side) / 2, (h - side) / 2, side, side, 0, 0, 256, 256);
    return c.toDataURL('image/jpeg', 0.85);
  }
  function logout() { setCur(null, false); }
  const nameOf = u => (u && (u.displayName || u.name)) || '';
  function photoStyle(node, u) {
    node.style.background = u ? u.color : '#c4cad6'; node.style.color = u ? '#fff' : '#1d2433';
    if (u && u.photo) { node.style.backgroundImage = 'url("' + u.photo + '")'; node.style.backgroundSize = 'cover'; node.style.backgroundPosition = 'center'; node.textContent = ''; }
  }
  function paint(btn) {
    btn.textContent = cur ? nameOf(cur).charAt(0).toUpperCase() : '👤';
    photoStyle(btn, cur);
    btn.title = cur ? nameOf(cur) + ' (hesap menüsü)' : 'Oturum aç / Kayıt ol';
    btn.setAttribute('aria-label', btn.title);
  }
  function avatar(u, size) {
    const a = el('span', 'ac-av', u ? nameOf(u).charAt(0).toUpperCase() : '👤');
    photoStyle(a, u);
    if (size) { a.style.width = a.style.height = size + 'px'; a.style.lineHeight = size + 'px'; a.style.fontSize = Math.round(size * 0.45) + 'px'; }
    return a;
  }

  // ---------- Giriş / kayıt penceresi ----------
  function closeDialog() { const m = document.getElementById('acct-modal'); if (m) m.remove(); document.removeEventListener('keydown', escDlg, true); }
  function escDlg(e) { if (e.key === 'Escape') { e.stopPropagation(); closeDialog(); } }
  function dialog(mode, opts) {
    opts = opts || {}; closeDialog(); closePop();
    const back = el('div', 'ac-back'); back.id = 'acct-modal';
    const card = el('div', 'ac-card'); card.setAttribute('role', 'dialog'); card.setAttribute('aria-modal', 'true'); card.setAttribute('aria-label', 'Kuduko hesabı');
    back.appendChild(card);
    back.addEventListener('mousedown', e => { if (e.target === back) closeDialog(); });
    document.addEventListener('keydown', escDlg, true);
    document.body.appendChild(back);
    const render = m => {
      card.replaceChildren();
      const head = el('div', 'ac-head'); head.appendChild(el('h2', '', 'Kuduko hesabı'));
      const x = el('button', 'ac-x', '✕'); x.setAttribute('aria-label', 'Kapat'); x.onclick = closeDialog; head.appendChild(x);
      const tabs = el('div', 'ac-tabs');
      [['login', 'Oturum aç'], ['register', 'Kayıt ol']].forEach(([id, l]) => { const b = el('button', 'ac-tab' + (m === id ? ' on' : ''), l); b.type = 'button'; b.onclick = () => render(id); tabs.appendChild(b); });
      const form = el('form', 'ac-form'); form.noValidate = true;
      const err = el('div', 'ac-err'); err.setAttribute('role', 'alert');
      const field = (label, type, ac, ph) => { const l = el('label'); l.appendChild(el('span', '', label)); const i = el('input'); i.type = type; i.autocomplete = ac; if (ph) i.placeholder = ph; l.appendChild(i); form.appendChild(l); return i; };
      let f = {};
      if (m === 'login') {
        if (users.length) {
          const quick = el('div', 'ac-quick');
          users.slice(0, 6).forEach(u => { const b = el('button', 'ac-chip'); b.type = 'button'; b.append(avatar(u, 22), u.name); b.onclick = () => { f.id.value = u.name; f.pass.focus(); }; quick.appendChild(b); });
          form.appendChild(quick);
        }
        f.id = field('Kullanıcı adı ya da e-posta', 'text', 'username');
        f.pass = field('Parola', 'password', 'current-password');
      } else {
        f.name = field('Kullanıcı adı', 'text', 'username', '3-24 karakter');
        f.email = field('E-posta (isteğe bağlı)', 'email', 'email');
        f.pass = field('Parola', 'password', 'new-password', 'En az 6 karakter');
        f.pass2 = field('Parola (tekrar)', 'password', 'new-password');
      }
      const rl = el('label', 'ac-rem'); const rc = el('input'); rc.type = 'checkbox'; rc.checked = true; rl.append(rc, 'Oturumu bu cihazda açık tut'); form.appendChild(rl);
      const go = el('button', 'ac-go', m === 'login' ? 'Oturum aç' : 'Hesap oluştur'); go.type = 'submit';
      form.append(err, go);
      form.onsubmit = async e => {
        e.preventDefault(); err.textContent = ''; go.disabled = true; go.textContent = 'Lütfen bekle…';
        const r = m === 'login'
          ? await login({ id: f.id.value, pass: f.pass.value, remember: rc.checked })
          : await register({ name: f.name.value, email: f.email.value, pass: f.pass.value, pass2: f.pass2.value, remember: rc.checked });
        go.disabled = false; go.textContent = m === 'login' ? 'Oturum aç' : 'Hesap oluştur';
        if (r.error) { err.textContent = r.error; return; }
        closeDialog(); if (opts.onDone) opts.onDone(r.user);
      };
      const foot = el('div', 'ac-foot');
      foot.appendChild(el('p', '', 'Hesap bu cihazda saklanır: parolan şifrelenerek (PBKDF2) kaydedilir, başka bir cihaza taşınmaz ve unutulursa sıfırlanamaz.'));
      const g = el('button', 'ac-guest', opts.guest ? 'Misafir olarak devam et' : 'Vazgeç'); g.type = 'button'; g.onclick = closeDialog; foot.appendChild(g);
      card.append(head, tabs, form, foot);
      setTimeout(() => { const first = form.querySelector('input'); if (first) first.focus(); }, 0);
    };
    render(mode === 'register' ? 'register' : 'login');
  }

  // ---------- Profili düzenle ----------
  function profileDialog() {
    if (!cur) return;
    closeDialog(); closePop();
    const back = el('div', 'ac-back'); back.id = 'acct-modal';
    const card = el('div', 'ac-card'); card.setAttribute('role', 'dialog'); card.setAttribute('aria-modal', 'true'); card.setAttribute('aria-label', 'Profili düzenle');
    back.appendChild(card); back.addEventListener('mousedown', e => { if (e.target === back) closeDialog(); });
    document.addEventListener('keydown', escDlg, true); document.body.appendChild(back);
    const head = el('div', 'ac-head'); head.appendChild(el('h2', '', 'Profili düzenle'));
    const x = el('button', 'ac-x', '✕'); x.setAttribute('aria-label', 'Kapat'); x.onclick = closeDialog; head.appendChild(x);
    // fotoğraf
    const ph = el('div', 'ac-photo'); let av = avatar(cur, 88); ph.appendChild(av);
    const pb = el('div', 'ac-photo-b'); const msgP = el('div', 'ac-ok');
    const fi = el('input'); fi.type = 'file'; fi.accept = 'image/*'; fi.style.display = 'none';
    const pick = el('button', 'ac-sm', 'Fotoğraf seç…'); pick.type = 'button'; pick.onclick = () => fi.click();
    const rm = el('button', 'ac-sm', 'Kaldır'); rm.type = 'button'; rm.disabled = !cur.photo;
    const refresh = () => { const n = avatar(cur, 88); ph.replaceChild(n, av); av = n; rm.disabled = !cur.photo; };
    fi.onchange = async () => {
      const f = fi.files && fi.files[0]; fi.value = ''; if (!f) return; msgP.className = 'ac-ok'; msgP.textContent = '';
      try { const r = await update({ photo: await photoFromFile(f) }); if (r.error) { msgP.className = 'ac-err'; msgP.textContent = r.error; } else { refresh(); msgP.textContent = 'Fotoğraf güncellendi.'; } }
      catch (e) { msgP.className = 'ac-err'; msgP.textContent = e.message; }
    };
    rm.onclick = async () => { await update({ photo: '' }); refresh(); msgP.className = 'ac-ok'; msgP.textContent = 'Fotoğraf kaldırıldı.'; };
    const brow = el('div', 'ac-prow'); brow.append(pick, rm); pb.append(brow, msgP, fi); ph.appendChild(pb);
    // bilgiler
    const f1 = el('form', 'ac-form'); f1.noValidate = true;
    const field = (form, label, type, ac, val) => { const l = el('label'); l.appendChild(el('span', '', label)); const i = el('input'); i.type = type; i.autocomplete = ac; if (val != null) i.value = val; l.appendChild(i); form.appendChild(l); return i; };
    const dn = field(f1, 'Görünen ad', 'text', 'name', cur.displayName || '');
    const un = field(f1, 'Kullanıcı adı', 'text', 'username', cur.name);
    const em = field(f1, 'E-posta', 'email', 'email', cur.email || '');
    const err1 = el('div', 'ac-err'); const ok1 = el('div', 'ac-ok'); const save = el('button', 'ac-go', 'Kaydet'); save.type = 'submit'; f1.append(err1, ok1, save);
    f1.onsubmit = async e => {
      e.preventDefault(); err1.textContent = ''; ok1.textContent = '';
      const r = await update({ displayName: dn.value, name: un.value, email: em.value });
      if (r.error) err1.textContent = r.error; else { ok1.textContent = 'Profil kaydedildi.'; refresh(); }
    };
    // parola
    const f2 = el('form', 'ac-form'); f2.noValidate = true;
    const op = field(f2, 'Eski parola', 'password', 'current-password');
    const np = field(f2, 'Yeni parola', 'password', 'new-password');
    const np2 = field(f2, 'Yeni parola (tekrar)', 'password', 'new-password');
    const err2 = el('div', 'ac-err'); const ok2 = el('div', 'ac-ok'); const sv2 = el('button', 'ac-go', 'Parolayı güncelle'); sv2.type = 'submit'; f2.append(err2, ok2, sv2);
    f2.onsubmit = async e => {
      e.preventDefault(); err2.textContent = ''; ok2.textContent = ''; sv2.disabled = true;
      const r = await changePassword(op.value, np.value, np2.value); sv2.disabled = false;
      if (r.error) err2.textContent = r.error; else { ok2.textContent = 'Parola güncellendi.'; op.value = np.value = np2.value = ''; }
    };
    card.append(head, ph, f1, el('div', 'ac-sec', 'Parolayı değiştir'), f2);
    setTimeout(() => dn.focus(), 0);
  }

  // ---------- Avatar menüsü ----------
  let pop = null;
  function closePop() { if (pop) { pop.remove(); pop = null; document.removeEventListener('click', outside, true); } }
  function outside(e) { if (pop && !pop.contains(e.target) && !e.target.closest('#acct')) closePop(); }
  function menu(anchor, hooks) {
    hooks = hooks || {};
    if (pop) { closePop(); return; }
    pop = el('div', 'ac-pop'); pop.setAttribute('role', 'menu');
    const top = el('div', 'ac-pop-top');
    top.appendChild(avatar(cur, 40));
    const tx = el('div'); tx.appendChild(el('b', '', cur ? nameOf(cur) : 'Misafir'));
    tx.appendChild(el('small', '', cur ? (cur.email || 'Yerel hesap') : 'Verilerin hesaba bağlı değil'));
    top.appendChild(tx); pop.appendChild(top);
    const item = (t, f) => { const b = el('button', 'ac-pi', t); b.setAttribute('role', 'menuitem'); b.onclick = () => { closePop(); f(); }; pop.appendChild(b); };
    if (!enabled) item('InPrivate pencerede hesap yok', () => { });
    else if (cur) {
      item('Profili düzenle', () => profileDialog());
      item('Hesap ayarları', () => hooks.settings && hooks.settings());
      item('Hesap değiştir', () => dialog('login', {}));
      item('Çıkış yap', () => logout());
    } else {
      item('Oturum aç', () => dialog('login', {}));
      item('Kayıt ol', () => dialog('register', {}));
    }
    document.body.appendChild(pop);
    const r = anchor.getBoundingClientRect();
    pop.style.top = (r.bottom + 8) + 'px'; pop.style.right = Math.max(8, innerWidth - r.right) + 'px';
    setTimeout(() => document.addEventListener('click', outside, true), 0);
  }

  const css = `
#acct{width:34px;height:34px;border-radius:50%;border:0;font:600 15px "Segoe UI",system-ui,sans-serif;flex:none;cursor:pointer}
#acct:hover{box-shadow:0 0 0 3px #2f6bff33}
.ac-av{display:inline-block;width:28px;height:28px;line-height:28px;border-radius:50%;text-align:center;font-weight:600;font-size:13px;flex:none}
.ac-back{position:fixed;inset:0;background:#10162299;z-index:200;display:flex;align-items:center;justify-content:center;padding:16px}
.ac-card{width:400px;max-width:100%;max-height:calc(100vh - 32px);overflow:auto;background:#fff;border-radius:16px;box-shadow:0 20px 60px #0006;padding:22px 24px;font-family:"Segoe UI",system-ui,sans-serif;color:#1d2433}
.ac-head{display:flex;align-items:center;margin-bottom:14px}
.ac-head h2{margin:0;flex:1;font-size:20px}
.ac-x{border:0;background:none;width:32px;height:32px;border-radius:8px;font-size:16px;cursor:pointer}
.ac-x:hover{background:#eef0f5}
.ac-tabs{display:flex;gap:4px;background:#f1f3f7;border-radius:10px;padding:4px;margin-bottom:16px}
.ac-tab{flex:1;border:0;background:none;border-radius:8px;height:34px;font:inherit;font-size:14px;cursor:pointer;color:#454c5e}
.ac-tab.on{background:#fff;color:#1a45c4;font-weight:600;box-shadow:0 1px 4px #0002}
.ac-form label{display:block;margin-bottom:12px;font-size:13px;color:#454c5e}
.ac-form label span{display:block;margin-bottom:4px}
.ac-form input[type=text],.ac-form input[type=email],.ac-form input[type=password]{width:100%;height:40px;border:1px solid #c4cad6;border-radius:10px;padding:0 12px;font:inherit;font-size:15px;outline:none;background:#fff}
.ac-form input:focus{border-color:#2f6bff;box-shadow:0 0 0 3px #2f6bff22}
.ac-form .ac-rem{display:flex;align-items:center;gap:8px;margin:4px 0 12px}
.ac-quick{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}
.ac-chip{display:inline-flex;align-items:center;gap:6px;border:1px solid #d5d9e2;background:#fff;border-radius:18px;padding:3px 12px 3px 4px;font:inherit;font-size:13px;cursor:pointer}
.ac-chip:hover{border-color:#2f6bff}
.ac-err{color:#c0281e;font-size:13px;min-height:18px;margin-bottom:8px}
.ac-go{width:100%;height:42px;border:0;border-radius:10px;background:#2f6bff;color:#fff;font:inherit;font-size:15px;font-weight:600;cursor:pointer}
.ac-go:hover:not(:disabled){background:#1a45c4}
.ac-go:disabled{opacity:.6;cursor:default}
.ac-foot{margin-top:14px;text-align:center}
.ac-foot p{font-size:12px;color:#6b7385;line-height:1.5;margin:0 0 10px}
.ac-guest{border:0;background:none;color:#1a45c4;font:inherit;font-size:14px;cursor:pointer}
.ac-guest:hover{text-decoration:underline}
.ac-av{background-size:cover;background-position:center}
.ac-photo{display:flex;align-items:center;gap:16px;margin-bottom:16px}
.ac-prow{display:flex;gap:8px;margin-bottom:6px}
.ac-sm{height:34px;padding:0 14px;border:1px solid #c4cad6;background:#f1f3f7;border-radius:8px;font:inherit;font-size:14px;cursor:pointer}
.ac-sm:hover:not(:disabled){border-color:#2f6bff}
.ac-sm:disabled{opacity:.5;cursor:default}
.ac-sec{font-size:12px;letter-spacing:.05em;text-transform:uppercase;color:#1a45c4;font-weight:700;margin:18px 0 10px;padding-top:14px;border-top:1px solid #e3e6ee}
.ac-ok{color:#1a7f4b;font-size:13px;min-height:18px;margin-bottom:8px}
.ac-pop{position:fixed;z-index:120;width:270px;background:#fff;border:1px solid #d5d9e2;border-radius:12px;box-shadow:0 8px 30px #1d243333;padding:6px 0;font-family:"Segoe UI",system-ui,sans-serif;color:#1d2433}
.ac-pop-top{display:flex;align-items:center;gap:12px;padding:12px 16px 12px;border-bottom:1px solid #e3e6ee;margin-bottom:6px}
.ac-pop-top b{display:block;font-size:15px}
.ac-pop-top small{color:#6b7385;font-size:12px}
.ac-pi{display:block;width:100%;text-align:left;border:0;background:none;padding:10px 16px;font:inherit;font-size:14px;cursor:pointer;color:inherit}
.ac-pi:hover{background:#eef0f5}
`;
  function init() { const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st); }
  return {
    enabled, G, init, register, login, logout, remove, dialog, menu, paint, avatar, closePop, profileDialog, update, changePassword, nameOf,
    onProfile: f => profileListeners.push(f),
    cur: () => cur, users: () => users.slice(), prefix: () => cur ? 'kuduko.u.' + cur.id + '.' : 'kuduko.',
    uidKey: () => cur ? cur.id : 'guest', onChange: f => listeners.push(f)
  };
})();
ACCT.init();

// ---- Arka plan görseli (kullanıcıya özel, bilgisayardan seçilir; IndexedDB'de saklanır) ----
const BG = (() => {
  const mem = {};
  function open() { return new Promise((res, rej) => { const r = indexedDB.open('kuduko-bg', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
  const key = () => 'bg:' + ACCT.uidKey();
  async function get() {
    if (PRIVATE) return mem[key()] || null;
    try { const db = await open(); return await new Promise(res => { const q = db.transaction('kv').objectStore('kv').get(key()); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); }); } catch (e) { return null; }
  }
  async function set(url) {
    if (PRIVATE) { mem[key()] = url; return; }
    const db = await open();
    await new Promise((res, rej) => { const tx = db.transaction('kv', 'readwrite'); tx.objectStore('kv').put(url, key()); tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
  }
  async function clear(k) {
    const kk = k || key();
    if (PRIVATE) { delete mem[kk]; return; }
    try { const db = await open(); await new Promise(res => { const tx = db.transaction('kv', 'readwrite'); tx.objectStore('kv').delete(kk); tx.oncomplete = res; tx.onerror = res; }); } catch (e) { }
  }
  function loadImage(file) {
    return new Promise((res, rej) => { const u = URL.createObjectURL(file), im = new Image(); im.onload = () => { URL.revokeObjectURL(u); res(im); }; im.onerror = () => { URL.revokeObjectURL(u); rej(new Error('Resim okunamadı.')); }; im.src = u; });
  }
  async function fromFile(file) {
    if (!file || !/^image\//.test(file.type)) throw new Error('Lütfen bir resim dosyası seç (JPG, PNG, WebP…).');
    if (file.size > 25 * 1024 * 1024) throw new Error('Dosya çok büyük (en fazla 25 MB).');
    let src; try { src = await createImageBitmap(file); } catch (e) { src = await loadImage(file); }
    const w = src.width || src.naturalWidth, h = src.height || src.naturalHeight;
    const k = Math.min(1, 1920 / Math.max(w, h));
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(h * k));
    c.getContext('2d').drawImage(src, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.86);
  }
  const css = url => 'linear-gradient(rgba(255,255,255,.28),rgba(255,255,255,.28)), url("' + url + '") center / cover no-repeat fixed';
  return { get, set, clear, fromFile, css };
})();

// ---- Ayarlar paneli (tüm bölümler) ----
const SETTINGS = (() => {
  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  const ZOOMS = [50, 67, 75, 80, 90, 100, 110, 125, 150, 175, 200];
  function build(body, ctx) {
    const S = ctx.S;
    const head = t => body.appendChild(el('div', 'st-h', t));
    const note = t => body.appendChild(el('p', 'st-n', t));
    const select = (label, key, opts, def, after) => {
      body.appendChild(el('div', 'sec', label)); const s = el('select'); s.setAttribute('aria-label', label);
      opts.forEach(([v, n]) => { const o = el('option', '', n); o.value = String(v); s.appendChild(o); });
      s.value = String(S.get(key, def)); s.onchange = () => { S.set(key, isNaN(+s.value) || key === 'start' || key === 'source' || key === 'lang' ? s.value : +s.value); if (after) after(s.value); ctx.toast('Ayar kaydedildi'); };
      body.appendChild(s); return s;
    };
    const check = (label, key, def) => {
      const row = el('label', 'chk'); const c = el('input'); c.type = 'checkbox'; c.checked = !!S.get(key, def);
      c.onchange = () => { S.set(key, c.checked); ctx.toast('Ayar kaydedildi'); }; row.append(c, label); body.appendChild(row);
    };
    const btn = (label, f, cls) => { const b = el('button', 'pb' + (cls ? ' ' + cls : ''), label); b.type = 'button'; b.onclick = f; return b; };
    const row = (...bs) => { const r = el('div', 'st-row'); bs.forEach(b => r.appendChild(b)); body.appendChild(r); return r; };

    // Hesap
    head('Hesap');
    const u = ACCT.cur();
    if (!ACCT.enabled) note('InPrivate pencerede hesap kullanılamaz.');
    else if (u) {
      const card = el('div', 'st-acct'); card.appendChild(ACCT.avatar(u, 44));
      const t = el('div'); t.appendChild(el('b', '', ACCT.nameOf(u))); t.appendChild(el('small', '', '@' + u.name + ' · ' + (u.email || 'Yerel hesap') + ' · ' + new Date(u.created).toLocaleDateString('tr-TR')));
      card.appendChild(t); body.appendChild(card);
      row(btn('Profili düzenle', () => ACCT.profileDialog(), 'pri'), btn('Hesap değiştir', () => ACCT.dialog('login', {})), btn('Çıkış yap', () => ACCT.logout()));
      const del = btn('Hesabı sil…', async () => {
        const p = prompt('Hesabı ve tüm verilerini (geçmiş, sık kullanılanlar, ayarlar, arka plan) kalıcı olarak silmek için parolanı yaz:');
        if (p == null) return;
        const r = await ACCT.remove(p); ctx.toast(r.error || 'Hesap silindi');
      }); del.classList.add('danger'); row(del);
    } else {
      note('Misafir olarak kullanıyorsun. Hesap açarsan geçmişin, sık kullanılanların, ayarların ve arka planın sana özel saklanır.');
      row(btn('Oturum aç', () => ACCT.dialog('login', {}), 'pri'), btn('Kayıt ol', () => ACCT.dialog('register', {})));
    }

    // Görünüm
    head('Görünüm');
    body.appendChild(el('div', 'sec', 'Ana sayfa arka planı'));
    const prev = el('div', 'st-bg'); prev.textContent = 'Arka plan yok'; body.appendChild(prev);
    const showBg = url => { prev.textContent = url ? '' : 'Arka plan yok'; prev.style.backgroundImage = url ? 'url("' + url + '")' : ''; rm.disabled = !url; };
    const fi = el('input'); fi.type = 'file'; fi.accept = 'image/*'; fi.style.display = 'none';
    const pick = btn('Bilgisayardan seç…', () => fi.click(), 'pri');
    const rm = btn('Kaldır', async () => { await BG.clear(); ctx.onBgChange(null); showBg(null); ctx.toast('Arka plan kaldırıldı'); });
    fi.onchange = async () => {
      const f = fi.files && fi.files[0]; fi.value = ''; if (!f) return;
      try { pick.disabled = true; const url = await BG.fromFile(f); await BG.set(url); ctx.onBgChange(url); showBg(url); ctx.toast('Arka plan değiştirildi'); }
      catch (e) { ctx.toast(e.message || 'Arka plan ayarlanamadı'); }
      pick.disabled = false;
    };
    row(pick, rm); body.appendChild(fi); showBg(null); BG.get().then(showBg);
    note('Resim yeni sekme (ana sayfa) arka planı olur. Hesabına özeldir.');
    select('Varsayılan yakınlaştırma', 'zoom', ZOOMS.map(z => [z, '%' + z]), 100, v => ctx.setZoom(+v));

    // Başlangıç
    head('Başlangıç');
    select('Yeni sekmede açılacak sayfa', 'start', [['home', 'Ana sayfa'], ['ai', 'Kuduko AI'], ['blank', 'Boş sayfa']], 'home');

    // Arama
    head('Arama');
    select('Arama kaynağı', 'source', [['ddg', 'Web (DuckDuckGo) + Vikipedi'], ['wiki', 'Sadece Vikipedi']], 'ddg', v => { if (ctx.onSource) ctx.onSource(v); });
    select('Sonuç dili', 'lang', [['tr', 'Türkçe sayfalar'], ['all', 'Tüm diller']], 'tr');

    // Gizlilik
    head('Gizlilik');
    check('Geçmişi kaydet', 'saveHistory', true);
    row(btn('Göz atma verilerini sil…', () => { ctx.closePanel(); ctx.openClearData(); }));

    // İndirmeler
    head('İndirmeler');
    if (ctx.openFolder) { note('Dosyalar bilgisayarındaki İndirilenler klasörüne iner.'); row(btn('İndirilenler klasörünü aç', ctx.openFolder), btn('İndirmeler sayfası', () => { ctx.closePanel(); ctx.openDownloads(); })); }
    else { note('Web sürümünde dosyalar tarayıcının indirme klasörüne iner.'); row(btn('İndirmeler sayfası', () => { ctx.closePanel(); ctx.openDownloads(); })); }

    // Kuduko AI
    head('Kuduko AI');
    note('Sağlayıcı, model ve API anahtarı Kuduko AI sekmesindeki ⚙ Ayarlar düğmesinden yönetilir.');
    row(btn('Kuduko AI\'yi aç', () => { ctx.closePanel(); ctx.openAI(); }));

    // Bağlantı testi (yalnızca web)
    if (ctx.netTest) {
      head('Bağlantı');
      note('Arama ya da yapay zekâ "bağlantı yok" diyorsa buradan test et: internet, Vikipedi, DuckDuckGo, ara sunucu ve yerleşik sunucu ayrı ayrı denenir.');
      const out = el('div', 'st-net'); row(btn('Bağlantıyı test et', async () => { out.replaceChildren(el('p', 'st-n', 'Test ediliyor…')); await ctx.netTest(out); }, 'pri')); body.appendChild(out);
    }

    // Sunucu (yalnızca web)
    if (ctx.server) {
      head('Sunucu');
      body.appendChild(el('div', 'sec', 'Sunucu adresi (isteğe bağlı, ör. https://kuduko.onrender.com)'));
      const sv = el('input'); sv.type = 'text'; sv.value = ctx.server.get() || ''; sv.placeholder = 'Boş: otomatik (aynı adres ya da localhost:3000)'; sv.setAttribute('aria-label', 'Sunucu adresi'); body.appendChild(sv);
      const st = el('p', 'st-n', 'Sunucu durumu denetleniyor…');
      row(btn('Kaydet ve yenile', () => { const v = sv.value.trim().replace(/\/+$/, ''); if (v && !/^https?:\/\//i.test(v)) { ctx.toast('Adres http:// ya da https:// ile başlamalı'); return; } ctx.server.set(v); }));
      body.appendChild(st); ctx.server.status().then(s => { st.textContent = s.ok ? '● Sunucu bağlı: ' + s.base : '○ Sunucu bağlı değil (BASLAT.bat ya da node index.html)'; });
    }

    // Sıfırla / hakkında
    head('Diğer');
    row(btn('Ayarları varsayılana döndür', () => {
      if (!confirm('Bu hesabın ayarları (başlangıç sayfası, arama, yakınlaştırma, geçmiş tercihi) varsayılana dönsün mü? Verilerin silinmez.')) return;
      ['start', 'source', 'lang', 'saveHistory', 'zoom'].forEach(k => S.set(k, null));
      ctx.setZoom(100); if (ctx.onSource) ctx.onSource('ddg'); ctx.toast('Ayarlar sıfırlandı'); ctx.rebuild();
    }), btn('Kuduko hakkında', () => { ctx.closePanel(); ctx.openAbout(); }));
  }
  const css = `
.st-h{font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:#1a45c4;font-weight:700;margin:22px 0 6px;padding-top:14px;border-top:1px solid #e3e6ee}
.st-h:first-child{margin-top:0;border-top:0;padding-top:0}
.st-n{font-size:12.5px;color:#6b7385;line-height:1.5;margin:6px 0 10px}
.st-row{display:flex;gap:8px;flex-wrap:wrap;margin:8px 0}
.st-bg{height:110px;border:1px dashed #c4cad6;border-radius:10px;display:grid;place-items:center;color:#6b7385;font-size:13px;background:#f7f8fb center/cover no-repeat;margin-bottom:8px}
.st-acct{display:flex;align-items:center;gap:12px;padding:10px 12px;border:1px solid #e3e6ee;border-radius:12px;margin-bottom:8px}
.st-acct b{display:block;font-size:15px}
.st-acct small{color:#6b7385;font-size:12px}
.pb.danger{color:#c0281e;border-color:#f3c4c0}
.pb.danger:hover{background:#fff3f2;border-color:#c0281e}
.pb:disabled{opacity:.5;cursor:default}
.net-t{list-style:none;margin:8px 0;padding:0;font-size:13px}
.net-t li{padding:3px 0;display:flex;gap:8px}
.net-t .ok{color:#1a7f4b}
.net-t .no{color:#c0281e}
.net-t small{color:#6b7385}
`;
  function init() { const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st); }
  return { build, init };
})();
SETTINGS.init();
// ---- Kuduko ses: sesli komut, ses tanıma, sesli okuma, kamera (web ve masaüstü ortak) ----
const VOICE = (() => {
  const SRC = window.SpeechRecognition || window.webkitSpeechRecognition;
  const electron = /Electron\//.test(navigator.userAgent);
  const canWS = !!SRC && !electron;                    // Electron'da Web Speech servisi çalışmaz
  const canRec = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
  const canTTS = 'speechSynthesis' in window;
  let cfgGet = () => null;
  const MSG = {
    'not-allowed': 'Mikrofon izni verilmedi. Adres çubuğundaki izin simgesinden mikrofona izin ver.',
    'service-not-allowed': 'Ses tanıma servisine izin verilmedi.',
    'no-speech': 'Ses algılanamadı. Tekrar dene.',
    'audio-capture': 'Mikrofon bulunamadı.',
    'network': 'Ses tanıma servisine ulaşılamadı.',
    'unsupported': 'Bu tarayıcı sesli tanımayı desteklemiyor. Chrome, Edge ya da Safari kullan.',
    'no-engine': 'Bu uygulamada sesli tanıma için OpenAI uyumlu (OpenAI, Groq) ya da Gemini API anahtarı gerekir. Kuduko AI > Ayarlar bölümünden ekle.'
  };
  function err(code, msg) { const e = new Error(msg || MSG[code] || ('Ses hatası: ' + code)); e.code = code; return e; }
  const looksLocal = b => /localhost|127\.0\.0\.1/.test(b || '');

  // ---------- Konuşmayı yazıya çevirme ----------
  function sttEngine(cfg) {
    if (!cfg) return null;
    if (cfg.provider === 'openai' && (cfg.key || looksLocal(cfg.base))) return blob => whisper(cfg, blob);
    if (cfg.provider === 'gemini' && cfg.key) return blob => geminiStt(cfg, blob);
    return null;
  }
  async function whisper(cfg, blob) {
    const base = (cfg.base || 'https://api.openai.com/v1').replace(/\/+$/, '');
    const model = cfg.sttModel || (/groq/.test(base) ? 'whisper-large-v3-turbo' : 'whisper-1');
    const fd = new FormData(); fd.append('file', blob, 'ses.webm'); fd.append('model', model); fd.append('language', 'tr');
    const r = await fetch(base + '/audio/transcriptions', { method: 'POST', headers: cfg.key ? { Authorization: 'Bearer ' + cfg.key } : {}, body: fd });
    if (!r.ok) { const e = new Error('HTTP ' + r.status); e.body = await r.text().catch(() => ''); throw e; }
    return ((await r.json()).text) || '';
  }
  const blobToB64 = blob => new Promise((res, rej) => { const f = new FileReader(); f.onload = () => res(String(f.result).split(',')[1]); f.onerror = () => rej(f.error); f.readAsDataURL(blob); });
  async function geminiStt(cfg, blob) {
    const model = cfg.sttModel || cfg.model || 'gemini-2.0-flash';
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': cfg.key },
      body: JSON.stringify({ contents: [{ parts: [{ text: 'Bu konuşmayı Türkçe olarak yazıya dök. Yalnızca konuşulan metni yaz, başka bir şey ekleme.' }, { inline_data: { mime_type: (blob.type || 'audio/webm').split(';')[0], data: await blobToB64(blob) } }] }] })
    });
    if (!r.ok) { const e = new Error('HTTP ' + r.status); e.body = await r.text().catch(() => ''); throw e; }
    const j = await r.json();
    return ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map(p => p.text || '').join('').trim();
  }
  function listenWS(o, setStop) {
    return new Promise((resolve, reject) => {
      const r = new SRC(); r.lang = o.lang || 'tr-TR'; r.interimResults = true; r.continuous = false; r.maxAlternatives = 1;
      let finalText = '', done = false;
      r.onresult = e => {
        let interim = '';
        for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) finalText += t; else interim += t; }
        if (o.onInterim) o.onInterim((finalText + interim).trim());
      };
      r.onerror = e => { if (done) return; done = true; reject(err(e.error)); };
      r.onend = () => { if (done) return; done = true; resolve(finalText.trim()); };
      setStop(() => { try { r.stop(); } catch (x) { } });
      try { r.start(); } catch (e) { done = true; reject(err('start', 'Ses tanıma başlatılamadı.')); }
    });
  }
  async function listenRec(o, setStop) {
    const eng = sttEngine(cfgGet());
    if (!eng) throw err('no-engine');
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (e) { throw err(e && e.name === 'NotFoundError' ? 'audio-capture' : 'not-allowed'); }
    const ac = new (window.AudioContext || window.webkitAudioContext)(), an = ac.createAnalyser(); an.fftSize = 1024;
    ac.createMediaStreamSource(stream).connect(an);
    const rec = new MediaRecorder(stream), chunks = [], buf = new Uint8Array(an.fftSize);
    rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    let heard = false, silentSince = Date.now(); const t0 = Date.now(); let stopped = false;
    const stopAll = () => { if (stopped) return; stopped = true; try { rec.stop(); } catch (e) { } };
    setStop(stopAll);
    const tick = setInterval(() => {
      an.getByteTimeDomainData(buf); let max = 0; for (let i = 0; i < buf.length; i++) max = Math.max(max, Math.abs(buf[i] - 128));
      const lvl = max / 128; if (o.onLevel) o.onLevel(lvl);
      if (lvl > 0.06) { heard = true; silentSince = Date.now(); }
      if ((heard && Date.now() - silentSince > 1400) || Date.now() - t0 > 20000 || (!heard && Date.now() - t0 > 8000)) stopAll();
    }, 100);
    const finished = new Promise(res => { rec.onstop = res; });
    rec.start(); await finished;
    clearInterval(tick); stream.getTracks().forEach(t => t.stop()); try { ac.close(); } catch (e) { }
    if (!heard) throw err('no-speech');
    if (o.onInterim) o.onInterim('Yazıya çevriliyor…');
    return (await eng(new Blob(chunks, { type: rec.mimeType || 'audio/webm' }))).trim();
  }
  // Tek bir cümle dinler. { promise, stop() } döner.
  function listen(o) {
    o = o || {}; let stopFn = () => { };
    const promise = (async () => {
      if (canWS) {
        try { return await listenWS(o, f => { stopFn = f; }); }
        catch (e) { if (!(['network', 'service-not-allowed', 'language-not-supported'].indexOf(e.code) >= 0) || !canRec || !sttEngine(cfgGet())) throw e; }
      }
      if (!canRec) throw err('unsupported');
      return await listenRec(o, f => { stopFn = f; });
    })();
    return { promise, stop: () => stopFn() };
  }

  // ---------- Sesli okuma ----------
  let speakToken = 0;
  function pickVoice() {
    const vs = speechSynthesis.getVoices() || [];
    return vs.find(v => /^tr/i.test(v.lang) && /online|natural/i.test(v.name)) || vs.find(v => /^tr/i.test(v.lang)) || null;
  }
  function chunks(text) {
    const parts = [], sentences = text.match(/[^.!?…\n]+[.!?…]{0,}/g) || [text]; let cur = '';
    sentences.forEach(s => { if ((cur + s).length > 180 && cur) { parts.push(cur); cur = s; } else cur += s; });
    if (cur.trim()) parts.push(cur); return parts.map(p => p.trim()).filter(Boolean);
  }
  function stopSpeaking() { speakToken++; if (canTTS) { try { speechSynthesis.cancel(); } catch (e) { } } }
  function speak(text) {
    return new Promise(resolve => {
      if (!canTTS || !text) return resolve(false);
      stopSpeaking(); const my = speakToken, parts = chunks(text), v = pickVoice(); let i = 0;
      const next = () => {
        if (my !== speakToken) return resolve(false);
        if (i >= parts.length) return resolve(true);
        const u = new SpeechSynthesisUtterance(parts[i++]); u.lang = 'tr-TR'; if (v) u.voice = v;
        u.onend = next; u.onerror = next; speechSynthesis.speak(u);
      };
      next();
    });
  }
  // Markdown, kaynak numaraları ve adresleri okunacak metinden ayıkla
  function clean(md) {
    return String(md || '').replace(/```[\s\S]*?```/g, ' kod bloğu ').replace(/`([^`]*)`/g, '$1').replace(/\[(\d+)\]/g, '')
      .replace(/\[([^\]]+)\]\(https?:[^)]+\)/g, '$1').replace(/https?:\/\/\S+/g, '').replace(/[*_#>~-]{1,}\s?/g, ' ').replace(/\s+/g, ' ').replace(/\s+([.,;:!?])/g, '$1').trim();
  }

  // ---------- Kamera ----------
  async function camera(videoEl) {
    if (!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) throw err('unsupported', 'Bu tarayıcıda kamera kullanılamıyor.');
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 1280 } }, audio: false }); }
    catch (e) { throw err(e && e.name === 'NotFoundError' ? 'audio-capture' : 'not-allowed', e && e.name === 'NotFoundError' ? 'Kamera bulunamadı.' : 'Kamera izni verilmedi. Adres çubuğundaki izin simgesinden kameraya izin ver.'); }
    videoEl.srcObject = stream; videoEl.muted = true; try { await videoEl.play(); } catch (e) { }
    return {
      stop: () => { stream.getTracks().forEach(t => t.stop()); videoEl.srcObject = null; },
      capture: () => {
        const w = videoEl.videoWidth || 640, h = videoEl.videoHeight || 480, k = Math.min(1, 768 / Math.max(w, h));
        const c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
        c.getContext('2d').drawImage(videoEl, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', 0.8);
      }
    };
  }

  // ---------- Küçük bildirim (sayfanın kendi bildirimi yoksa) ----------
  let tt = null;
  function notify(msg) {
    let t = document.getElementById('vc-toast');
    if (!t) { t = document.createElement('div'); t.id = 'vc-toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
    t.textContent = msg; t.style.display = 'block'; clearTimeout(tt); tt = setTimeout(() => { t.style.display = 'none'; }, 4500);
  }

  // ---------- Metin kutusuna mikrofon düğmesi: söylediğin metni yazar ve arar ----------
  function mic(input, onText, o) {
    o = o || {};
    const wrap = input.parentElement; if (getComputedStyle(wrap).position === 'static') wrap.style.position = 'relative';
    const b = document.createElement('button'); b.type = 'button'; b.className = 'vc-mic'; b.textContent = '🎤'; b.title = 'Sesli arama'; b.setAttribute('aria-label', 'Sesli arama');
    wrap.appendChild(b); let h = null;
    b.onclick = async e => {
      e.preventDefault(); e.stopPropagation();
      if (h) { h.stop(); return; }
      const ph = input.placeholder; b.classList.add('on'); b.textContent = '⏺'; input.placeholder = 'Dinliyorum… konuş';
      h = listen({ onInterim: t => { if (t) input.value = t; } });
      try { const text = (await h.promise).replace(/[.!?…]+$/, '').trim(); if (text) { input.value = text; onText(text); } else (o.onError || notify)('Ses algılanamadı. Tekrar dene.'); }
      catch (er) { (o.onError || notify)(er.message || 'Ses tanıma başarısız.'); }
      finally { h = null; b.classList.remove('on'); b.textContent = '🎤'; input.placeholder = ph; }
    };
    return b;
  }

  const css = `
.vc-mic{position:absolute;top:50%;right:8px;transform:translateY(-50%);width:32px;height:32px;border-radius:50%;border:0;background:none;font-size:16px;cursor:pointer;padding:0;line-height:32px}
.vc-mic:hover{background:#0001}
.vc-mic.on{background:#e8453c;color:#fff;animation:vcp 1s ease-in-out infinite}
@keyframes vcp{50%{box-shadow:0 0 0 6px #e8453c44}}
@media(prefers-reduced-motion:reduce){.vc-mic.on{animation:none}}
#vc-toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#1d2433;color:#fff;padding:10px 18px;border-radius:8px;font:14px "Segoe UI",system-ui,sans-serif;z-index:300;display:none;max-width:90vw;text-align:center}
`;
  function init() { const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st); }
  return {
    listen, speak, stopSpeaking, clean, camera, mic, notify, init,
    setConfigSource: f => { cfgGet = f; },
    sttProblem: () => (canWS || (canRec && sttEngine(cfgGet()))) ? '' : (canRec ? MSG['no-engine'] : MSG['unsupported']),
    supported: () => ({ stt: canWS || (canRec && !!sttEngine(cfgGet())), tts: canTTS, camera: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia), ws: canWS, rec: canRec, engine: !!sttEngine(cfgGet()) }),
    MSG
  };
})();
VOICE.init();

function kudukoAiCfg() {
  try { const c = JSON.parse(localStorage.getItem('kuduko.ai') || 'null'); if (!c) return null; const keys = c.keys || {}; return { provider: c.provider, key: keys[c.provider] || c.key || '', base: c.base, model: c.model, sttModel: c.sttModel }; } catch (e) { return null; }
}


const $ = id => document.getElementById(id);
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
const base = u => (u || '').split('?')[0].split('#')[0];
const isHome = u => base(u) === HOME, isSearch = u => base(u) === SEARCH, isError = u => base(u) === ERROR, isDownloads = u => base(u) === DOWNLOADS;
const errParam = (u, k) => { try { return new URL(u).searchParams.get(k) || ''; } catch { return ''; } };
const searchQ = u => { try { return new URL(u).searchParams.get('q') || ''; } catch { return ''; } };
const mem = {};
const S = {
  get(k, d) { try { if (PRIVATE && mem[k] != null) return mem[k]; const v = localStorage.getItem(ACCT.prefix() + k); if (v == null) return d; const p = JSON.parse(v); return p === null ? d : p; } catch { return d; } },
  set(k, v) { try { if (PRIVATE) mem[k] = v; else localStorage.setItem(ACCT.prefix() + k, JSON.stringify(v)); } catch {} }
};
let toastT;
function toast(msg) { const t = $('toast'); t.textContent = msg; t.style.display = 'block'; clearTimeout(toastT); toastT = setTimeout(() => t.style.display = 'none', 3200); }
const fmtSize = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : n > 1024 ? Math.round(n / 1024) + ' KB' : (n || 0) + ' B';
const fmtTime = t => new Date(t).toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'short' });
const uid = () => Date.now() + '' + Math.random().toString(36).slice(2, 6);
const GROUPS = { 'Kırmızı': '#e8453c', 'Mavi': '#2f6bff', 'Yeşil': '#1fa463', 'Sarı': '#f5b400' };
const safe = fn => { try { return fn(); } catch { return undefined; } };

function toURL(text) {
  text = text.trim();
  if (!text) return HOME;
  if (/^(https?|file):\/\//i.test(text)) return text;
  if (/^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(text)) return 'https://' + text;
  return SEARCH + '?q=' + encodeURIComponent(text) + (S.get('lang', 'tr') === 'all' ? '&lang=all' : '');
}

/* ================= Sekmeler ================= */
let tabs = [], active = null, splitTab = null, zoom = S.get('zoom', 100);

function tabLabel(tab) {
  const u = tab.url || '';
  if (isHome(u)) return 'Yeni sekme';
  if (u === 'about:blank') return 'Boş sayfa';
  if (isError(u)) return 'Sayfa açılamadı';
  if (isDownloads(u)) return 'İndirmeler';
  if (isSearch(u)) return searchQ(u) || 'Ara';
  if (tab.title) return tab.title;
  try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; }
}

function startUrl() {
  const s = S.get('start', 'home');
  if (s === 'ai') return SEARCH + '?tab=ai';
  if (s === 'blank') return 'about:blank';
  return HOME;
}
function newTab(url, noSelect) {
  url = url || startUrl();
  const wv = document.createElement('webview');
  if (PARTITION) wv.setAttribute('partition', PARTITION);
  wv.setAttribute('preload', PRELOAD); wv.setAttribute('allowpopups', '');
  wv.src = url; $('views').appendChild(wv);
  const tab = { wv, url, title: '', group: null, ready: false, tabEl: el('div', 'tab') };
  tab.tabEl.appendChild(el('span', '', 'Yeni sekme'));
  const x = el('b', '', '×'); x.title = 'Kapat'; tab.tabEl.appendChild(x);
  $('tabs').insertBefore(tab.tabEl, $('newtab'));
  tab.tabEl.onclick = () => select(tab);
  x.onclick = e => { e.stopPropagation(); closeTab(tab); };

  wv.addEventListener('dom-ready', () => { tab.ready = true; safe(() => wv.setZoomFactor(zoom / 100)); injectBg(tab); relabel(tab); });
  wv.addEventListener('page-title-updated', e => {
    tab.title = e.title; relabel(tab);
    const h = S.get('history', []); if (h[0] && h[0].url === tab.url && !isSearch(tab.url)) { h[0].title = e.title; S.set('history', h); }
  });
  const nav = e => { if (e.isMainFrame === false) return; tab.url = e.url; tab.title = ''; record(tab); relabel(tab); };
  wv.addEventListener('did-navigate', nav); wv.addEventListener('did-navigate-in-page', nav);
  wv.addEventListener('did-fail-load', e => {
    if (!e.isMainFrame || e.errorCode === -3 || e.errorCode === 0 || isError(e.validatedURL)) return;
    wv.loadURL(ERROR + '?u=' + encodeURIComponent(e.validatedURL) + '&c=' + encodeURIComponent(e.errorDescription));
  });
  wv.addEventListener('did-stop-loading', () => { if (tab.ready && tab === active) updateChrome(); });
  wv.addEventListener('found-in-page', e => { if (tab === active) $('fmsg').textContent = e.result.matches ? e.result.activeMatchOrdinal + '/' + e.result.matches : 'Bulunamadı'; });
  tabs.push(tab); relabel(tab);
  if (!noSelect) select(tab); else layout();
  return tab;
}
function relabel(tab) { tab.tabEl.firstChild.textContent = tabLabel(tab); if (tab === active) updateChrome(); }

function select(tab) {
  if (splitTab && tab === splitTab) splitTab = active;
  active = tab; layout(); updateChrome();
}
function layout() {
  tabs.forEach(t => {
    t.tabEl.classList.toggle('active', t === active);
    const show = t === active || t === splitTab;
    t.wv.style.display = show ? 'flex' : 'none';
    t.wv.style.left = '0'; t.wv.style.right = '0'; t.wv.style.borderLeft = '';
    if (splitTab && t === active) t.wv.style.right = '50%';
    if (splitTab && t === splitTab) { t.wv.style.left = '50%'; t.wv.style.borderLeft = '2px solid #d5d9e2'; }
  });
}
function closeTab(tab) {
  const i = tabs.indexOf(tab);
  if (tab === splitTab) splitTab = null;
  tab.wv.remove(); tab.tabEl.remove(); tabs.splice(i, 1);
  if (!tabs.length) newTab();
  else if (tab === active) select(tabs[Math.max(0, i - 1)]);
  else layout();
}
function updateChrome() {
  const tab = active; if (!tab) return;
  const u = tab.url || '';
  $('url').value = isHome(u) || u === 'about:blank' ? '' : isSearch(u) ? searchQ(u) : isError(u) ? errParam(u, 'u') : isDownloads(u) ? 'kuduko://indirmeler' : u;
  $('back').disabled = !(tab.ready && safe(() => tab.wv.canGoBack()));
  $('fwd').disabled = !(tab.ready && safe(() => tab.wv.canGoForward()));
  const fav = !isHome(u) && S.get('favs', []).some(f => f.url === u);
  $('star').textContent = fav ? '★' : '☆'; $('star').style.color = fav ? '#f5b400' : '';
  tabs.forEach(t => { t.tabEl.style.borderTopColor = t.group || 'transparent'; });
  document.title = (isSearch(u) ? searchQ(u) + ' - ' : '') + 'Kuduko' + (PRIVATE ? ' (InPrivate)' : '');
}
const navTo = text => { active.wv.loadURL(toURL(text)); };

/* ================= Geçmiş kaydı ================= */
function record(tab) {
  const u = tab.url;
  if (PRIVATE || !S.get('saveHistory', true)) return;
  if (isHome(u) || u === 'about:blank' || isError(u) || isDownloads(u) || !/^(https?:|file:)/.test(u)) return;
  const h = S.get('history', []); if (h[0] && h[0].url === u) return;
  h.unshift({ url: u, title: isSearch(u) ? searchQ(u) : (() => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; } })(), time: Date.now() });
  S.set('history', h.slice(0, 500));
}

/* ================= Panel altyapısı ================= */
let panel = null, panelKind = null;
function closePanel() { if (panel) { panel.remove(); panel = null; panelKind = null; } }
function openPanel(kind, title, build) {
  closeMenu();
  if (panelKind === kind) { closePanel(); return; }
  closePanel(); panelKind = kind;
  panel = el('div', 'pn'); panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', title);
  const h = el('div', 'pnh'); h.appendChild(el('h3', '', title));
  const x = el('button', 'ib', '✕'); x.setAttribute('aria-label', 'Kapat'); x.onclick = closePanel; h.appendChild(x);
  const body = el('div', 'pnb'); panel.append(h, body); document.body.appendChild(panel);
  { const top = menuTop(); panel.style.top = top + 'px'; panel.style.maxHeight = Math.max(240, innerHeight - top - 12) + 'px'; }
  panel._build = () => { body.replaceChildren(); build(body); };
  panel._build();
}
function refreshPanel(kind) { if (panel && panelKind === kind) panel._build(); }

/* ---- Sık kullanılanlar ---- */
function toggleFavorite() {
  const u = active.url;
  if (isHome(u)) { toast('Ana sayfa eklenemez'); return; }
  let f = S.get('favs', []);
  if (f.some(x => x.url === u)) { f = f.filter(x => x.url !== u); toast('Sık kullanılanlardan çıkarıldı'); }
  else { f.unshift({ url: u, title: tabLabel(active) }); toast('Sık kullanılanlara eklendi'); }
  S.set('favs', f); updateChrome(); refreshPanel('favs');
}
function openFavorites() {
  openPanel('favs', 'Sık kullanılanlar', body => {
    const f = S.get('favs', []);
    const add = el('button', 'pb pri', '★ Bu sayfayı ekle / çıkar'); add.onclick = toggleFavorite; body.appendChild(add);
    if (!f.length) body.appendChild(el('div', 'empty', 'Henüz sık kullanılan yok. Adres çubuğundaki ☆ simgesiyle ekleyebilirsin.'));
    f.forEach(x => {
      const li = el('div', 'li'); const tx = el('div', 'tx clk');
      tx.append(el('b', '', x.title), el('small', '', isSearch(x.url) ? 'Arama' : x.url));
      tx.onclick = () => active.wv.loadURL(x.url);
      const d = el('button', 'ib', '✕'); d.onclick = () => { S.set('favs', S.get('favs', []).filter(z => z.url !== x.url)); updateChrome(); refreshPanel('favs'); };
      li.append(tx, d); body.appendChild(li);
    });
  });
}

/* ---- Geçmiş ---- */
function openHistory() {
  let filter = '';
  openPanel('history', 'Geçmiş', body => {
    const q = el('input'); q.type = 'text'; q.placeholder = 'Geçmişte ara'; q.value = filter; q.setAttribute('aria-label', 'Geçmişte ara');
    const list = el('div');
    const draw = () => {
      list.replaceChildren();
      const h = S.get('history', []).filter(x => (x.title + x.url).toLowerCase().includes(filter.toLowerCase())).slice(0, 100);
      if (!h.length) list.appendChild(el('div', 'empty', PRIVATE ? 'InPrivate pencerede geçmiş kaydedilmez.' : 'Geçmiş boş.'));
      h.forEach(x => {
        const li = el('div', 'li'); const tx = el('div', 'tx clk');
        tx.append(el('b', '', x.title), el('small', '', fmtTime(x.time) + ' · ' + (isSearch(x.url) ? 'Arama' : x.url)));
        tx.onclick = () => active.wv.loadURL(x.url); li.appendChild(tx); list.appendChild(li);
      });
    };
    q.oninput = () => { filter = q.value; draw(); };
    const c = el('button', 'pb', 'Geçmişi sil'); c.style.marginTop = '12px';
    c.onclick = () => { S.set('history', []); draw(); toast('Geçmiş silindi'); };
    body.append(q, list, c); draw();
  });
}

/* ---- İndirilenler: tam sayfa (downloads.html); liste ana süreçte tutulur ---- */
ipcRenderer.on('dl:start', (e, d) => toast('İndiriliyor: ' + d.name));
ipcRenderer.on('dl:done', (e, p) => toast(p.state === 'completed' ? 'İndirildi: ' + p.name : 'İndirme ' + (p.state === 'cancelled' ? 'iptal edildi' : 'başarısız') + ': ' + p.name));
const dlUrl = () => DOWNLOADS + '?u=' + encodeURIComponent(ACCT.uidKey()) + (PRIVATE ? '&private=1' : '');
function openDownloads() {
  closeMenu(); closePanel();
  const ex = tabs.find(t => isDownloads(t.url));
  if (ex) select(ex); else newTab(dlUrl());
}

/* ---- Parolalar (ana parola ile AES-GCM şifreli) ---- */
let vault = null;
const b64 = u => btoa(String.fromCharCode(...u)), unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function vkey(pass, salt) {
  const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 200000, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function vsave() {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, vault.key, new TextEncoder().encode(JSON.stringify(vault.items)));
  S.set('vault', { salt: b64(vault.salt), iv: b64(iv), data: b64(new Uint8Array(ct)) });
}
async function vunlock(pass) {
  const v = S.get('vault', null);
  if (!v) { const salt = crypto.getRandomValues(new Uint8Array(16)); vault = { key: await vkey(pass, salt), salt, items: [] }; await vsave(); return; }
  const salt = unb64(v.salt), key = await vkey(pass, salt);
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(v.iv) }, key, unb64(v.data));
  vault = { key, salt, items: JSON.parse(new TextDecoder().decode(pt)) };
}
function openPasswords() {
  openPanel('pass', 'Parolalar', body => {
    if (!window.crypto || !crypto.subtle) { body.appendChild(el('div', 'empty', 'Bu özellik bu ortamda kullanılamıyor.')); return; }
    if (!vault) {
      const has = !!S.get('vault', null);
      body.appendChild(el('p', '', has ? 'Parolalarını görmek için ana parolanı gir.' : 'Parolaların ana parolanla şifrelenerek bu cihazda saklanır. Bir ana parola belirle. Unutursan geri getirilemez.'));
      const p = el('input'); p.type = 'password'; p.placeholder = 'Ana parola'; p.setAttribute('aria-label', 'Ana parola');
      const b = el('button', 'pb pri', has ? 'Kilidi aç' : 'Oluştur'); const msg = el('div', 'empty');
      const run = async () => { try { if (p.value.length < 4) { msg.textContent = 'En az 4 karakter gir.'; return; } await vunlock(p.value); refreshPanel('pass'); } catch { msg.textContent = 'Ana parola yanlış.'; } };
      p.onkeydown = e => { if (e.key === 'Enter') run(); }; b.onclick = run;
      body.append(p, b, msg); return;
    }
    const site = el('input'); site.type = 'text'; site.placeholder = 'Site'; site.setAttribute('aria-label', 'Site');
    const user = el('input'); user.type = 'text'; user.placeholder = 'Kullanıcı adı'; user.setAttribute('aria-label', 'Kullanıcı adı');
    const pw = el('input'); pw.type = 'password'; pw.placeholder = 'Parola'; pw.setAttribute('aria-label', 'Parola');
    const add = el('button', 'pb pri', 'Kaydet');
    add.onclick = async () => { if (!site.value.trim() || !pw.value) return; vault.items.unshift({ site: site.value.trim(), user: user.value.trim(), pass: pw.value }); await vsave(); refreshPanel('pass'); };
    body.append(site, user, pw, add);
    if (!vault.items.length) body.appendChild(el('div', 'empty', 'Kayıtlı parola yok.'));
    vault.items.forEach(it => {
      const li = el('div', 'li'); const tx = el('div', 'tx'); const sm = el('small', '', it.user + ' · ••••••••');
      tx.append(el('b', '', it.site), sm); let shown = false;
      const eye = el('button', 'ib', '👁'); eye.title = 'Göster / gizle'; eye.onclick = () => { shown = !shown; sm.textContent = it.user + ' · ' + (shown ? it.pass : '••••••••'); };
      const cp = el('button', 'ib', '⧉'); cp.title = 'Parolayı kopyala'; cp.onclick = () => navigator.clipboard.writeText(it.pass).then(() => toast('Parola kopyalandı'), () => toast('Kopyalanamadı'));
      const dl = el('button', 'ib', '✕'); dl.title = 'Sil'; dl.onclick = async () => { vault.items = vault.items.filter(z => z !== it); await vsave(); refreshPanel('pass'); };
      li.append(tx, eye, cp, dl); body.appendChild(li);
    });
    const lock = el('button', 'pb', 'Kilitle'); lock.style.marginTop = '12px'; lock.onclick = () => { vault = null; refreshPanel('pass'); }; body.appendChild(lock);
  });
}

/* ---- Göz atma verilerini sil ---- */
function openClearData() {
  openPanel('clear', 'Göz atma verilerini sil', body => {
    const opts = [['history', 'Geçmiş', true], ['downloads', 'İndirme listesi (dosyalar silinmez)', true], ['cookies', 'Çerezler, site verileri ve önbellek', true], ['favs', 'Sık kullanılanlar', false], ['vault', 'Kayıtlı parolalar', false], ['notes', 'Hızlı notlar', false]];
    const boxes = opts.map(([k, l, on]) => { const row = el('label', 'chk'); const c = el('input'); c.type = 'checkbox'; c.checked = on; row.append(c, l); body.appendChild(row); return [k, c]; });
    const b = el('button', 'pb pri', 'Şimdi sil'); b.style.marginTop = '10px';
    b.onclick = async () => {
      for (const [k, c] of boxes) {
        if (!c.checked) continue;
        if (k === 'cookies') { await ipcRenderer.invoke('clear-session'); continue; }
        if (k === 'downloads') { ipcRenderer.send('dl:clear', ACCT.uidKey()); continue; }
        S.set(k, k === 'notes' ? '' : k === 'vault' ? null : []);
        if (k === 'vault') vault = null;
      }
      updateChrome(); closePanel(); toast('Seçilen veriler silindi');
    };
    body.appendChild(b);
  });
}

/* ---- Çevir ---- */
function openTranslate() {
  openPanel('translate', 'Çevir', body => {
    const langs = [['tr', 'Türkçe'], ['en', 'İngilizce'], ['de', 'Almanca'], ['fr', 'Fransızca'], ['es', 'İspanyolca'], ['ru', 'Rusça'], ['ar', 'Arapça']];
    const mk = def => { const s = el('select'); langs.forEach(([c, n]) => { const o = el('option', '', n); o.value = c; s.appendChild(o); }); s.value = def; return s; };
    const from = mk('en'), to = mk('tr'), ta = el('textarea'); ta.placeholder = 'Çevrilecek metin (en fazla 500 karakter)'; ta.maxLength = 500; ta.setAttribute('aria-label', 'Çevrilecek metin');
    const out = el('div', 'note'); out.style.display = 'none';
    const b = el('button', 'pb pri', 'Çevir');
    b.onclick = async () => {
      if (!ta.value.trim()) return;
      if (from.value === to.value) { out.style.display = 'block'; out.textContent = ta.value; return; }
      out.style.display = 'block'; out.textContent = 'Çevriliyor…';
      try { const r = await fetch('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(ta.value) + '&langpair=' + from.value + '|' + to.value); const j = await r.json(); out.textContent = j.responseData.translatedText; }
      catch { out.textContent = 'Çeviri yapılamadı. Bağlantını kontrol et.'; }
    };
    body.append(el('div', 'sec', 'Kaynak dil'), from, el('div', 'sec', 'Hedef dil'), to, ta, b, out);
    if (/^https?:/.test(active.url)) {
      const o = el('button', 'pb', 'Açık siteyi Türkçeye çevrilmiş aç'); o.style.marginTop = '14px';
      o.onclick = () => { newTab('https://translate.google.com/translate?sl=auto&tl=tr&u=' + encodeURIComponent(active.url)); closePanel(); };
      body.appendChild(o);
    }
  });
}

/* ---- Hızlı notlar ---- */
function openNotes() {
  openPanel('notes', 'Hızlı notlar', body => {
    const ta = el('textarea'); ta.style.minHeight = '240px'; ta.value = S.get('notes', '') || ''; ta.placeholder = 'Notların otomatik kaydedilir'; ta.setAttribute('aria-label', 'Notlar');
    ta.oninput = () => S.set('notes', ta.value); body.appendChild(ta);
  });
}

/* ---- Ayarlar ---- */
let bgUrl = null;
function injectBg(tab) {
  if (!bgUrl || !isHome(tab.url)) return;
  const css = 'html,body{background:' + BG.css(bgUrl) + ' !important}.logo{filter:drop-shadow(0 2px 8px #fffc)}input,button,a.b{background-color:#fffffff2!important}';
  safe(() => tab.wv.insertCSS(css));
}
function refreshHomes() { tabs.forEach(t => { if (isHome(t.url)) safe(() => t.wv.reload()); }); }
const settingsCtx = () => ({
  S, toast, closePanel, openClearData, setZoom, openDownloads, openAbout,
  openAI: () => { active.wv.loadURL(SEARCH + '?tab=ai'); },
  onBgChange: url => { bgUrl = url; refreshHomes(); },
  onSource: v => ipcRenderer.send('source:set', v),
  rebuild: () => refreshPanel('settings'),
  openFolder: () => ipcRenderer.send('dl:folder')
});
function openSettings() {
  openPanel('settings', 'Ayarlar', body => SETTINGS.build(body, settingsCtx()));
  if (panel && panelKind === 'settings') panel.style.width = '460px';
}

/* ---- Yardım ---- */
const SHORTCUTS = [['Yeni sekme', 'Ctrl+T'], ['Sekmeyi kapat', 'Ctrl+W'], ['Yeni pencere', 'Ctrl+N'], ['Yeni InPrivate penceresi', 'Ctrl+Shift+N'], ['Adres çubuğuna git', 'Ctrl+L'], ['Sık kullanılanlar', 'Ctrl+Shift+O'], ['Geçmiş', 'Ctrl+H'], ['İndirilenler', 'Ctrl+J'], ['Sayfada bul', 'Ctrl+F'], ['Ekran görüntüsü', 'Ctrl+Shift+S'], ['Verileri sil', 'Ctrl+Shift+Del'], ['Yazdır', 'Ctrl+P'], ['Tam ekran', 'F11'], ['Menüyü / panelleri kapat', 'Esc']];
function openShortcuts() {
  openPanel('keys', 'Klavye kısayolları', body => {
    const t = el('table', 'kb'); SHORTCUTS.forEach(([a, k]) => { const r = el('tr'); r.append(el('td', '', a), el('td', '', k)); t.appendChild(r); }); body.appendChild(t);
  });
}
function openAbout() {
  openPanel('about', 'Kuduko hakkında', body => {
    body.appendChild(el('p', '', 'Kuduko, kendi arama sayfası ve yapay zekâ asistanı olan bir tarayıcıdır.'));
    body.appendChild(el('p', '', 'Sürüm 1.1 · Arama: DuckDuckGo + Vikipedi · Çeviri: MyMemory'));
  });
}

/* ================= Diğer menü işlevleri ================= */
function newWindow(priv) { ipcRenderer.send('new-window', !!priv); }
function setZoom(v) {
  zoom = Math.max(50, Math.min(200, v)); S.set('zoom', zoom);
  tabs.forEach(t => { if (t.ready) safe(() => t.wv.setZoomFactor(zoom / 100)); });
  const o = $('zoomv'); if (o) o.textContent = '%' + zoom;
}
const toggleFullscreen = () => ipcRenderer.send('fullscreen');
function toggleSplit() {
  closeMenu();
  if (splitTab) { splitTab = null; layout(); toast('Bölünmüş ekran kapatıldı'); return; }
  splitTab = tabs.find(t => t !== active) || newTab(HOME, true); layout();
  toast('Bölünmüş ekran: sağ taraf için sekmeyi sekme çubuğundan seç');
}
function printPage() { closeMenu(); closePanel(); setTimeout(() => safe(() => active.wv.print()), 80); }
async function screenshot() {
  closeMenu(); closePanel();
  try {
    const img = await active.wv.capturePage();
    const r = await ipcRenderer.invoke('save-file', { name: 'kuduko-ekran-' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.png', data: img.toPNG(), priv: PRIVATE });
    toast('Ekran görüntüsü kaydedildi: ' + r.name);
  } catch { toast('Ekran görüntüsü alınamadı'); }
}
function openFind() { closeMenu(); $('find').classList.add('on'); $('findq').focus(); $('findq').select(); }
let lastFind = '';
function doFind(back) {
  const q = $('findq').value; if (!q) { safe(() => active.wv.stopFindInPage('clearSelection')); return; }
  const next = q === lastFind; lastFind = q;
  safe(() => active.wv.findInPage(q, next ? { forward: !back, findNext: true } : { forward: !back }));
}
function closeFind() { $('find').classList.remove('on'); lastFind = ''; tabs.forEach(t => safe(() => t.wv.stopFindInPage('clearSelection'))); $('fmsg').textContent = ''; }
async function savePage() {
  closeMenu();
  try {
    const r = await ipcRenderer.invoke('save-page', { wcId: active.wv.getWebContentsId(), name: tabLabel(active) || 'sayfa', priv: PRIVATE });
    toast('Sayfa kaydedildi: ' + r.name);
  } catch { toast('Sayfa kaydedilemedi'); }
}
function duplicateTab() { closeMenu(); newTab(active.url); }
function setGroup(color) { closeMenu(); active.group = color; updateChrome(); toast(color ? 'Sekme gruba eklendi' : 'Sekme gruptan çıkarıldı'); }
function closeGroup() { closeMenu(); const g = active.group; if (!g) { toast('Bu sekme bir grupta değil'); return; } tabs.filter(t => t.group === g).forEach(t => closeTab(t)); }

/* ================= Üç nokta menüsü ================= */
function menuItems() {
  return [
    { i: '▦', l: 'Yeni sekme', k: 'Ctrl+T', f: () => { closeMenu(); newTab(); } },
    { i: '▢', l: 'Yeni pencere', k: 'Ctrl+N', f: () => { closeMenu(); newWindow(); } },
    { i: '◐', l: 'Yeni InPrivate penceresi', k: 'Ctrl+Shift+N', f: () => { closeMenu(); newWindow(true); } },
    'sep', { zoom: true }, 'sep',
    { i: '☆', l: 'Sık kullanılanlar', k: 'Ctrl+Shift+O', f: openFavorites },
    { i: '↺', l: 'Geçmiş', k: 'Ctrl+H', f: openHistory },
    { i: '▭', l: 'Sekme grupları', sub: [
      ...Object.entries(GROUPS).map(([n, c]) => ({ i: '●', ic: c, l: n + ' gruba ekle', f: () => setGroup(c) })),
      'sep', { i: '○', l: 'Gruptan çıkar', f: () => setGroup(null) }, { i: '✕', l: 'Gruptaki sekmeleri kapat', f: closeGroup }] },
    { i: '⇩', l: 'İndirilenler', k: 'Ctrl+J', f: openDownloads },
    { i: '✱', l: 'Uzantılar', sub: [
      { i: '✎', l: 'Hızlı notlar', f: openNotes }, { i: '✦', l: 'Kuduko AI', f: () => { closeMenu(); active.wv.loadURL(SEARCH + '?tab=ai'); } }] },
    { i: '⚿', l: 'Parolalar', f: openPasswords },
    'sep',
    { i: '🗑', l: 'Göz atma verilerini sil', k: 'Ctrl+Shift+Del', f: openClearData },
    { i: '⎙', l: 'Yazdır', k: 'Ctrl+P', f: printPage },
    { i: 'あ', l: 'Çevir', f: openTranslate },
    { i: '◫', l: 'Bölünmüş ekran', f: toggleSplit },
    { i: '⛶', l: 'Ekran Görüntüsü', k: 'Ctrl+Shift+S', f: screenshot },
    { i: '⌕', l: 'Sayfada bul', k: 'Ctrl+F', f: openFind },
    { i: '', l: 'Diğer araçlar', sub: [
      { i: '⇩', l: 'Sayfayı kaydet', f: savePage }, { i: '⧉', l: 'Sekmeyi çoğalt', f: duplicateTab },
      { i: '⤢', l: 'Tam ekran', k: 'F11', f: () => { closeMenu(); toggleFullscreen(); } }] },
    'sep',
    { i: '⚙', l: 'Ayarlar', f: openSettings },
    { i: '?', l: 'Yardım ve geri bildirim', sub: [
      { i: 'ⓘ', l: 'Kuduko hakkında', f: openAbout }, { i: '⌨', l: 'Klavye kısayolları', f: openShortcuts }] }
  ];
}
let subT = null;
const cancelClose = () => { clearTimeout(subT); subT = null; };
const closeSubLater = () => { cancelClose(); subT = setTimeout(closeSub, 220); };
function mkItem(it, inSub) {
  const b = el('button', 'mi'); b.type = 'button'; b.setAttribute('role', 'menuitem');
  const ic = el('span', 'ic', it.i || ''); if (it.ic) ic.style.color = it.ic;
  b.append(ic, el('span', 'lb', it.l));
  if (it.k) b.appendChild(el('span', 'ky', it.k));
  if (it.sub) {
    b.appendChild(el('span', 'ar', '▶')); b.setAttribute('aria-haspopup', 'true');
    b.onclick = e => { e.stopPropagation(); openSub(b, it.sub, e.detail === 0); };
    b.onmouseenter = () => { cancelClose(); if (innerWidth > 700) openSub(b, it.sub, false); };
  } else {
    if (!inSub) b.onmouseenter = closeSubLater;   // alt menüdeki öğeler alt menüyü kapatmamalı
    b.onclick = e => { e.stopPropagation(); it.f(); };
  }
  return b;
}
function closeSub() { cancelClose(); const s = $('submenu'); if (s) s.remove(); document.querySelectorAll('.mi.open').forEach(x => x.classList.remove('open')); }
function openSub(anchor, items, focusFirst) {
  cancelClose();
  if (anchor.classList.contains('open') && $('submenu')) { if (focusFirst) { const f = $('submenu').querySelector('.mi'); if (f) f.focus(); } return; }
  closeSub(); anchor.classList.add('open');
  const s = el('div'); s.id = 'submenu'; s.setAttribute('role', 'menu');
  items.forEach(it => s.appendChild(it === 'sep' ? el('div', 'msep') : mkItem(it, true)));
  s.onmouseenter = cancelClose;
  s.addEventListener('keydown', e => menuKeys(e, s, anchor));
  document.body.appendChild(s);
  const mr = $('menu').getBoundingClientRect(), ar = anchor.getBoundingClientRect();
  let left = mr.left - s.offsetWidth - 6; if (left < 8) left = Math.max(8, mr.left + 8);
  s.style.left = left + 'px'; s.style.top = Math.max(8, Math.min(ar.top, innerHeight - s.offsetHeight - 8)) + 'px';
  if (focusFirst) { const f = s.querySelector('.mi'); if (f) f.focus(); }
}
// Klavye: ↑ ↓ Home End gezinme, → alt menü, ← geri
function menuKeys(e, root, parentBtn) {
  const list = Array.from(root.querySelectorAll(':scope > .mi, :scope > .mz button'));
  const i = list.indexOf(document.activeElement);
  const focus = n => { if (list.length) list[(n + list.length) % list.length].focus(); };
  if (e.key === 'ArrowDown') { e.preventDefault(); focus(i < 0 ? 0 : i + 1); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); focus(i < 0 ? -1 : i - 1); }
  else if (e.key === 'Home') { e.preventDefault(); focus(0); }
  else if (e.key === 'End') { e.preventDefault(); focus(-1); }
  else if (e.key === 'ArrowRight' && root.id === 'menu' && document.activeElement && document.activeElement.getAttribute('aria-haspopup')) { e.preventDefault(); document.activeElement.click(); }
  else if (e.key === 'ArrowLeft' && root.id === 'submenu') { e.preventDefault(); closeSub(); if (parentBtn) parentBtn.focus(); }
}
const menuTop = () => Math.round($('bar').getBoundingClientRect().bottom) + 6;
function buildMenu() {
  const m = $('menu'); m.replaceChildren();
  menuItems().forEach(it => {
    if (it === 'sep') { m.appendChild(el('div', 'msep')); return; }
    if (it.zoom) {
      const z = el('div', 'mz'); z.appendChild(el('span', 'ic', '⊕')); z.appendChild(el('span', 'lb', 'Yakınlaştır'));
      const mi = el('button', '', '−'), pl = el('button', '', '+'), fs = el('button', '', '⤢'), o = el('output', '', '%' + zoom); o.id = 'zoomv';
      mi.setAttribute('aria-label', 'Uzaklaştır'); pl.setAttribute('aria-label', 'Yakınlaştır'); fs.setAttribute('aria-label', 'Tam ekran');
      mi.onclick = e => { e.stopPropagation(); setZoom(zoom - 10); }; pl.onclick = e => { e.stopPropagation(); setZoom(zoom + 10); };
      fs.onclick = e => { e.stopPropagation(); closeMenu(); toggleFullscreen(); };
      z.append(mi, o, pl, fs); z.onmouseenter = closeSubLater; m.appendChild(z); return;
    }
    m.appendChild(mkItem(it));
  });
}
function openMenu(focusFirst) {
  buildMenu(); const m = $('menu'), top = menuTop();
  m.style.top = top + 'px'; m.style.maxHeight = Math.max(200, innerHeight - top - 12) + 'px';
  m.classList.add('on'); m.scrollTop = 0; $('menuBtn').setAttribute('aria-expanded', 'true');
  if (focusFirst) { const f = m.querySelector('.mi'); if (f) f.focus(); }
}
function closeMenu() { $('menu').classList.remove('on'); closeSub(); $('menuBtn').setAttribute('aria-expanded', 'false'); }
$('menuBtn').onclick = e => { e.stopPropagation(); closePanel(); if ($('menu').classList.contains('on')) closeMenu(); else openMenu(e.detail === 0); };
$('menu').addEventListener('keydown', e => menuKeys(e, $('menu'), null));
document.addEventListener('click', e => { if (!e.target.closest('#menu,#submenu')) closeMenu(); });
// Sayfa (webview) içine tıklayınca da menü kapansın
window.addEventListener('blur', () => closeMenu());

/* ================= Üst çubuk & kısayollar ================= */
$('newtab').onclick = () => newTab();
$('back').onclick = () => safe(() => active.wv.goBack());
$('fwd').onclick = () => safe(() => active.wv.goForward());
$('reload').onclick = () => safe(() => active.wv.reload());
$('home').onclick = () => active.wv.loadURL(HOME);
$('star').onclick = toggleFavorite;
$('url').addEventListener('keydown', e => { if (e.key === 'Enter') { navTo($('url').value); active.wv.focus(); } });
$('findq').addEventListener('keydown', e => { if (e.key === 'Enter') doFind(e.shiftKey); });
$('fnext').onclick = () => doFind(false); $('fprev').onclick = () => doFind(true); $('fclose').onclick = closeFind;

const focusUrl = () => { $('url').focus(); $('url').select(); };
const KEYS = {
  'Ctrl+T': () => newTab(), 'Ctrl+W': () => closeTab(active), 'Ctrl+N': () => newWindow(), 'Ctrl+Shift+N': () => newWindow(true),
  'Ctrl+Shift+O': openFavorites, 'Ctrl+H': openHistory, 'Ctrl+J': openDownloads, 'Ctrl+Shift+Delete': openClearData,
  'Ctrl+P': printPage, 'Ctrl+Shift+S': screenshot, 'Ctrl+F': openFind, 'Ctrl+L': focusUrl, 'F11': toggleFullscreen,
  'Escape': () => { const was = $('menu').classList.contains('on'); closeMenu(); closePanel(); closeFind(); if (was) $('menuBtn').focus(); }
};
const comboOf = e => (e.ctrlKey ? 'Ctrl+' : '') + (e.shiftKey ? 'Shift+' : '') + (e.altKey ? 'Alt+' : '') + (e.key.length === 1 ? e.key.toUpperCase() : e.key);
document.addEventListener('keydown', e => { const c = comboOf(e); if (KEYS[c]) { if (c !== 'Escape') e.preventDefault(); KEYS[c](); } });
ipcRenderer.on('shortcut', (e, c) => { if (KEYS[c]) KEYS[c](); });
ipcRenderer.on('open-tab', (e, url) => newTab(url));

async function applyUser() {
  vault = null; setZoom(S.get('zoom', 100)); ACCT.paint($('acct')); closePanel(); updateChrome();
  ipcRenderer.send('user:set', ACCT.uidKey()); ipcRenderer.send('source:set', S.get('source', 'ddg'));
  tabs.forEach(t => { if (isDownloads(t.url)) safe(() => t.wv.loadURL(dlUrl())); });
  bgUrl = await BG.get(); refreshHomes();
}
ACCT.onChange(u => {
  if (u && u.removed) { BG.clear('bg:' + u.removed); ipcRenderer.send('dl:clear', u.removed); return; }
  applyUser().then(() => { const c = ACCT.cur(); toast(c ? 'Hoş geldin, ' + ACCT.nameOf(c) : 'Oturum kapatıldı (misafir)'); });
});
if (PRIVATE) $('acct').style.display = 'none';
ACCT.paint($('acct'));
$('acct').onclick = e => { e.stopPropagation(); ACCT.menu($('acct'), { settings: openSettings }); };
VOICE.setConfigSource(kudukoAiCfg);
VOICE.mic($('url'), text => { active.wv.loadURL(SEARCH + '?q=' + encodeURIComponent(text) + (S.get('lang', 'tr') === 'all' ? '&lang=all' : '')); }, { onError: toast });
ACCT.onProfile(() => { ACCT.paint($('acct')); refreshPanel('settings'); });
ipcRenderer.send('user:set', ACCT.uidKey());
ipcRenderer.send('source:set', S.get('source', 'ddg'));
(async () => {
  bgUrl = await BG.get();
  newTab();
  if (ACCT.enabled && ACCT.users().length && !ACCT.cur()) ACCT.dialog('login', { guest: true });
})();
