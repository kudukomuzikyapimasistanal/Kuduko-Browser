const { app, BrowserWindow, Menu, ipcMain, shell, session, webContents } = require('electron');
const path = require('path');
const fs = require('fs');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
// Siteler "Electron" görünce engellemesin diye gerçek Chrome gibi tanıtıl
const CHROME_MAJOR = process.versions.chrome.split('.')[0];
const CHROME_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + CHROME_MAJOR + '.0.0.0 Safari/537.36';
app.userAgentFallback = CHROME_UA;
let source = 'ddg';

/* ---------- Arama (DuckDuckGo + Vikipedi) ---------- */
const decode = s => s.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ');
const strip = s => decode(s.replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();

// DuckDuckGo "Sonraki" formundaki gizli alanlardan sonraki sayfa sorgusunu çıkarır
function parseNext(html) {
  const forms = html.match(/<form[\s\S]*?<\/form>/g) || [];
  for (const f of forms) {
    if (!/value="Next"/i.test(f)) continue;
    const p = new URLSearchParams();
    (f.match(/<input[^>]*>/g) || []).forEach(tag => {
      if (!/type="hidden"/i.test(tag)) return;
      const n = (tag.match(/name="([^"]*)"/) || [])[1], v = (tag.match(/value="([^"]*)"/) || [])[1];
      if (n) p.set(n, decode(v || ''));
    });
    if (p.get('s')) return p.toString();
  }
  return null;
}
async function webSearch(q, o, nextQs) {
  o = o || {};
  const url = nextQs ? 'https://html.duckduckgo.com/html/?' + nextQs : 'https://html.duckduckgo.com/html/?kl=' + (o.lang === 'all' ? 'wt-wt' : 'tr-tr') + (/^[dwmy]$/.test(o.df || '') ? '&df=' + o.df : '') + '&q=' + encodeURIComponent(q);
  const r = await fetch(url, { headers: { 'User-Agent': UA, 'Accept-Language': 'tr-TR,tr;q=0.9' }, signal: AbortSignal.timeout(12000) });
  if (!r.ok) throw new Error('Sunucu yanıtı: ' + r.status);
  const html = await r.text(), out = [];
  html.split('class="result__a"').slice(1).forEach(chunk => {
    const href = (chunk.match(/href="([^"]+)"/) || [])[1];
    const title = (chunk.match(/>([\s\S]*?)<\/a>/) || [])[1];
    const snip = (chunk.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/a>/) || [])[1];
    if (!href || !title || href.includes('duckduckgo.com/y.js')) return;
    let u2 = decode(href);
    try { const u = new URL(u2.startsWith('//') ? 'https:' + u2 : u2); u2 = u.searchParams.get('uddg') || u.href; } catch { return; }
    out.push({ title: strip(title), url: u2, snippet: snip ? strip(snip) : '' });
  });
  return { items: out.slice(0, 50), next: parseNext(html) };
}
async function wikiSearch(q, n = 3, off = 0) {
  const r = await fetch('https://tr.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=' + n + '&sroffset=' + off + '&srsearch=' + encodeURIComponent(q), { headers: { 'User-Agent': 'Kuduko/1.0' } });
  const j = await r.json();
  const items = (j.query?.search || []).map(s => ({ title: s.title, snippet: strip(s.snippet), url: 'https://tr.wikipedia.org/wiki/' + encodeURIComponent(s.title.replace(/ /g, '_')) }));
  items.total = j.query?.searchinfo?.totalhits || 0; items.hasNext = !!j.continue;
  return items;
}
// Sayfalı arama: sayfa başına 10 sonuç; sonraki parti gerektikçe DuckDuckGo'dan alınır
const sCache = new Map(), PER = 10;
ipcMain.handle('search', async (e, q, o) => {
  o = o || {};
  const page = Math.max(1, Math.min(50, +o.page || 1));
  if (source === 'wiki') {
    try { const w = await wikiSearch(q, PER, (page - 1) * PER); return { web: w, webError: null, wiki: [], page, pages: Math.min(50, Math.max(1, Math.ceil(w.total / PER))), hasNext: w.hasNext }; }
    catch (err) { return { web: [], webError: String(err.message || err), wiki: [], page, pages: 1, hasNext: false }; }
  }
  const key = JSON.stringify([q, o.df || '', o.lang || 'tr']);
  let c = sCache.get(key);
  if (!c || Date.now() - c.t > 300000) {
    try { const r = await webSearch(q, o); c = { web: r.items, next: r.next, done: !r.next, t: Date.now() }; sCache.set(key, c); if (sCache.size > 40) sCache.delete(sCache.keys().next().value); }
    catch (err) {
      const wiki = page === 1 ? await wikiSearch(q, 3).catch(() => []) : [];
      return { web: [], webError: String(err.message || err), wiki, page, pages: 1, hasNext: false };
    }
  }
  while (c.web.length < page * PER && c.next && !c.done) {
    try {
      const r = await webSearch(q, o, c.next), seen = new Set(c.web.map(x => x.url)), add = r.items.filter(x => !seen.has(x.url));
      if (!add.length) { c.done = true; c.next = null; } else { c.web = c.web.concat(add); c.next = r.next; c.done = !r.next; }
    } catch (err) { c.done = true; c.next = null; }
  }
  const more = c.web.length > page * PER || (c.next && !c.done);
  const wiki = page === 1 ? await wikiSearch(q, 3).catch(() => []) : [];
  return { web: c.web.slice((page - 1) * PER, page * PER), webError: null, wiki, page, pages: more ? null : Math.max(1, Math.ceil(c.web.length / PER)), hasNext: !!more };
});
// Arama sekmeleri (Görseller, Videolar, Haberler...) için genel getirme (CORS yok, Chrome gibi)
async function fetchRemote(url) {
  if (!/^https?:\/\//i.test(url)) throw new Error('Geçersiz adres');
  const r = await fetch(url, { headers: { 'User-Agent': CHROME_UA, 'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8' }, signal: AbortSignal.timeout(15000) });
  return r;
}
// Kuduko Yapay Zekâ: istekleri ana süreçte yap (CORS yok), yanıtı parça parça sayfaya ilet
const aiAborts = new Map();
ipcMain.on('ai:start', async (e, req) => {
  const send = m => { if (!e.sender.isDestroyed()) e.sender.send('ai:chunk', Object.assign({ id: req.id }, m)); };
  const ac = new AbortController(); aiAborts.set(req.id, ac);
  try {
    if (!/^https?:\/\//i.test(req.url)) throw new Error('Geçersiz adres');
    const r = await fetch(req.url, { method: 'POST', headers: req.headers, body: JSON.stringify(req.body), signal: ac.signal });
    if (!r.ok) { send({ done: true, error: 'HTTP ' + r.status, body: (await r.text()).slice(0, 600) }); return; }
    const rd = r.body.getReader(), dec = new TextDecoder();
    for (;;) { const { done, value } = await rd.read(); if (done) break; send({ chunk: dec.decode(value, { stream: true }) }); }
    send({ done: true });
  } catch (err) { send({ done: true, error: err.name === 'AbortError' ? 'iptal' : String(err.message || err) }); }
  finally { aiAborts.delete(req.id); }
});
ipcMain.on('ai:cancel', (e, id) => { const a = aiAborts.get(id); if (a) a.abort(); });
ipcMain.handle('fetch-text', async (e, url) => (await fetchRemote(url)).text());
ipcMain.handle('fetch-json', async (e, url) => (await fetchRemote(url)).json());
ipcMain.on('source:set', (e, v) => { source = v === 'wiki' ? 'wiki' : 'ddg'; });

/* ---------- Pencereler ---------- */
function createWindow(priv) {
  const win = new BrowserWindow({
    width: 1280, height: 800, minWidth: 700, minHeight: 500,
    title: priv ? 'Kuduko (InPrivate)' : 'Kuduko', backgroundColor: '#ffffff',
    webPreferences: { webviewTag: true, contextIsolation: false, nodeIntegration: true }
  });
  win.loadFile(path.join(__dirname, 'index.html'), priv ? { query: { private: '1', p: String(Date.now()) } } : undefined);
  return win;
}
const hostWin = wc => BrowserWindow.fromWebContents(wc.hostWebContents || wc);

ipcMain.on('new-window', (e, priv) => createWindow(!!priv));
ipcMain.on('fullscreen', e => { const w = BrowserWindow.fromWebContents(e.sender); if (w) w.setFullScreen(!w.isFullScreen()); });
ipcMain.handle('clear-session', async e => { await e.sender.session.clearStorageData(); await e.sender.session.clearCache(); return true; });

/* ---------- İndirmeler ---------- */
function uniquePath(dir, name) {
  const ext = path.extname(name), base = path.basename(name, ext);
  let p = path.join(dir, name), n = 1;
  while (fs.existsSync(p)) p = path.join(dir, base + ' (' + (n++) + ')' + ext);
  return p;
}
// İndirme listesi ana süreçte tutulur (diske kaydedilir); İndirmeler sayfası buradan okur
let dlList = null;
const dlFile = () => path.join(app.getPath('userData'), 'downloads.json');
function dlLoad() {
  if (dlList) return dlList;
  try { dlList = JSON.parse(fs.readFileSync(dlFile(), 'utf8')).map(d => d.status === 'indiriliyor' ? Object.assign({}, d, { status: 'yarım kaldı' }) : d); } catch (e) { dlList = []; }
  return dlList;
}
let dlSaveT = null, dlBcT = 0;
function dlPersist() { clearTimeout(dlSaveT); dlSaveT = setTimeout(() => { try { fs.writeFileSync(dlFile(), JSON.stringify(dlLoad().slice(0, 500))); } catch (e) { } }, 300); }
function dlBroadcast(force) {
  const now = Date.now(); if (!force && now - dlBcT < 250) return; dlBcT = now;
  webContents.getAllWebContents().forEach(c => { if (!c.isDestroyed()) c.send('dl:changed'); });
}
const dlById = id => dlLoad().find(d => d.id === id);
const winUsers = new Map();   // pencere (webContents.id) -> geçerli kullanıcı
ipcMain.on('user:set', (e, uid) => winUsers.set(e.sender.id, String(uid || 'guest')));
const uidOf = wcId => winUsers.get(wcId) || 'guest';
function dlAdd(rec) {
  const d = Object.assign({ id: Date.now() + '-' + Math.random().toString(36).slice(2, 6), time: Date.now(), status: 'tamamlandı', loaded: 0, total: 0, src: '' }, rec);
  dlLoad().unshift(d); dlPersist(); dlBroadcast(true); return d;
}
ipcMain.handle('dl:list', (e, uid) => dlLoad().filter(d => (d.uid || 'guest') === (uid || 'guest')).map(d => Object.assign({}, d, { missing: d.status === 'tamamlandı' && d.path ? !fs.existsSync(d.path) : false })));
ipcMain.on('dl:remove', (e, id) => { dlList = dlLoad().filter(d => d.id !== id); dlPersist(); dlBroadcast(true); });
ipcMain.on('dl:clear', (e, uid) => { dlList = dlLoad().filter(d => (d.uid || 'guest') !== (uid || 'guest')); dlPersist(); dlBroadcast(true); });
ipcMain.on('dl:folder', () => shell.openPath(app.getPath('downloads')));
ipcMain.on('dl:open', (e, id) => { const d = dlById(id); if (d && d.path) shell.openPath(d.path); });
ipcMain.on('dl:show', (e, id) => { const d = dlById(id); if (d && d.path) shell.showItemInFolder(d.path); });
ipcMain.on('dl:trash', async (e, id) => { const d = dlById(id); if (d && d.path) { try { await shell.trashItem(d.path); } catch (err) { } dlBroadcast(true); } });
ipcMain.on('dl:retry', (e, id) => { const d = dlById(id); if (d && /^https?:\/\//i.test(d.src || '')) e.sender.downloadURL(d.src); });
ipcMain.on('dl:url', (e, url) => { if (/^https?:\/\//i.test(url || '')) e.sender.downloadURL(url); });
ipcMain.handle('save-file', (e, { name, data, priv }) => {
  const p = uniquePath(app.getPath('downloads'), name);
  fs.writeFileSync(p, Buffer.from(data));
  const r = { name: path.basename(p), path: p, size: fs.statSync(p).size };
  if (!priv) dlAdd(Object.assign({ uid: uidOf(e.sender.id) }, r));
  return r;
});
ipcMain.handle('save-page', async (e, { wcId, name, priv }) => {
  const wc = webContents.fromId(wcId);
  const p = uniquePath(app.getPath('downloads'), name.replace(/[\\/:*?"<>|]/g, '_') + '.html');
  await wc.savePage(p, 'HTMLComplete');
  const r = { name: path.basename(p), path: p, size: fs.existsSync(p) ? fs.statSync(p).size : 0 };
  if (!priv) dlAdd(Object.assign({ uid: uidOf(e.sender.id) }, r));
  return r;
});

const hooked = new WeakSet();
function hookSession(ses) {
  if (hooked.has(ses)) return; hooked.add(ses);
  ses.setUserAgent(CHROME_UA);
  // Google / YouTube / Instagram tarayıcıyı Chrome sansın: istemci ipuçlarını (Client Hints) da Chrome yap
  ses.webRequest.onBeforeSendHeaders((d, cb) => {
    const h = d.requestHeaders;
    for (const k of Object.keys(h)) if (/^sec-ch-ua(-mobile|-platform)?$/i.test(k)) delete h[k];
    h['sec-ch-ua'] = '"Chromium";v="' + CHROME_MAJOR + '", "Google Chrome";v="' + CHROME_MAJOR + '", "Not.A/Brand";v="99"';
    h['sec-ch-ua-mobile'] = '?0';
    h['sec-ch-ua-platform'] = '"Windows"';
    cb({ requestHeaders: h });
  });
  // Sitelerin çerçeve (iframe) ve gömme engellerini kaldır
  ses.webRequest.onHeadersReceived((d, cb) => {
    const h = { ...d.responseHeaders };
    for (const k of Object.keys(h)) {
      const l = k.toLowerCase();
      if (l === 'x-frame-options') delete h[k];
      else if (l === 'content-security-policy' || l === 'content-security-policy-report-only')
        h[k] = h[k].map(v => v.replace(/frame-ancestors[^;]*;?/gi, ''));
    }
    cb({ responseHeaders: h });
  });
  // Konum, kamera, mikrofon, bildirim vb. izin istekleri engellenmesin
  ses.setPermissionRequestHandler((wc, perm, cb) => cb(true));
  ses.setPermissionCheckHandler(() => true);
  ses.on('will-download', (e, item, wc) => {
    const bw = hostWin(wc); if (!bw) return;
    const target = uniquePath(app.getPath('downloads'), item.getFilename());
    item.setSavePath(target);
    const track = ses === session.defaultSession;   // InPrivate indirmeleri listeye yazılmaz
    let src = item.getURL(); if (!/^https?:\/\//i.test(src)) src = '';
    const rec = { id: Date.now() + '-' + Math.random().toString(36).slice(2, 6), uid: uidOf(bw.webContents.id), name: path.basename(target), path: target, total: item.getTotalBytes(), loaded: 0, size: 0, time: Date.now(), status: 'indiriliyor', src };
    if (track) { dlLoad().unshift(rec); dlPersist(); dlBroadcast(true); }
    const send = (ch, d) => { if (!bw.isDestroyed()) bw.webContents.send(ch, d); };
    send('dl:start', rec);
    item.on('updated', () => { rec.loaded = item.getReceivedBytes(); rec.total = item.getTotalBytes(); if (track) dlBroadcast(false); });
    item.once('done', (ev, state) => {
      rec.status = state === 'completed' ? 'tamamlandı' : state === 'cancelled' ? 'iptal edildi' : 'başarısız';
      rec.size = item.getReceivedBytes();
      if (track) { dlPersist(); dlBroadcast(true); }
      send('dl:done', { id: rec.id, state, size: rec.size, name: rec.name });
    });
  });
}
app.on('session-created', hookSession);

/* ---------- Kısayollar (sayfa içindeyken de çalışsın) ---------- */
const FORWARD = new Set(['Ctrl+T', 'Ctrl+W', 'Ctrl+N', 'Ctrl+Shift+N', 'Ctrl+Shift+O', 'Ctrl+H', 'Ctrl+J', 'Ctrl+Shift+Delete', 'Ctrl+P', 'Ctrl+Shift+S', 'Ctrl+F', 'Ctrl+L', 'F11', 'Escape']);
const comboOf = i => (i.control ? 'Ctrl+' : '') + (i.shift ? 'Shift+' : '') + (i.alt ? 'Alt+' : '') + (i.key.length === 1 ? i.key.toUpperCase() : i.key);

app.on('web-contents-created', (e, contents) => {
  if (contents.getType() !== 'webview') return;
  contents.setWindowOpenHandler(({ url }) => {
    const bw = hostWin(contents); if (bw) bw.webContents.send('open-tab', url);
    return { action: 'deny' };
  });
  contents.on('before-input-event', (ev, input) => {
    if (input.type !== 'keyDown') return;
    const c = comboOf(input);
    if (!FORWARD.has(c)) return;
    const bw = hostWin(contents); if (!bw) return;
    if (c !== 'Escape') ev.preventDefault();
    bw.webContents.send('shortcut', c);
  });
});

app.whenReady().then(() => {
  hookSession(session.defaultSession);
  Menu.setApplicationMenu(null);
  createWindow(false);
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(false); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
