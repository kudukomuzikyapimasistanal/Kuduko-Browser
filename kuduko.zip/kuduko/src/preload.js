const { contextBridge, ipcRenderer, webFrame } = require('electron');

// Sayfalar navigator.userAgentData ile "Electron" ı fark edemesin (Google girişi vb.)
try {
  const major = process.versions.chrome.split('.')[0];
  webFrame.executeJavaScript(`(function(){try{
    var b=[{brand:'Chromium',version:'${major}'},{brand:'Google Chrome',version:'${major}'},{brand:'Not.A/Brand',version:'99'}];
    var full=b.map(function(x){return{brand:x.brand,version:x.version+'.0.0.0'}});
    var data={brands:b,mobile:false,platform:'Windows'};
    Object.defineProperty(navigator,'userAgentData',{configurable:true,get:function(){return{
      brands:b,mobile:false,platform:'Windows',
      getHighEntropyValues:function(){return Promise.resolve({brands:b,mobile:false,platform:'Windows',platformVersion:'10.0.0',architecture:'x86',bitness:'64',model:'',uaFullVersion:'${major}.0.0.0',fullVersionList:full})},
      toJSON:function(){return data}}}});
  }catch(e){}})();`);
} catch {}

// Sadece Kuduko'nun kendi (file://) sayfalarına arama köprüsü verir
if (location.protocol === 'file:') {
  contextBridge.exposeInMainWorld('kuduko', {
    search: (q, o) => ipcRenderer.invoke('search', q, o),
    fetchText: u => ipcRenderer.invoke('fetch-text', u),
    fetchJson: u => ipcRenderer.invoke('fetch-json', u),
    aiStream: (req, onChunk) => new Promise((resolve, reject) => {
      const h = (ev, m) => {
        if (m.id !== req.id) return;
        if (m.chunk != null) onChunk(m.chunk);
        if (m.done) { ipcRenderer.removeListener('ai:chunk', h); if (m.error) { const e = new Error(m.error); e.body = m.body; reject(e); } else resolve(); }
      };
      ipcRenderer.on('ai:chunk', h); ipcRenderer.send('ai:start', req);
    }),
    aiCancel: id => ipcRenderer.send('ai:cancel', id),
    dl: {
      list: uid => ipcRenderer.invoke('dl:list', uid),
      remove: id => ipcRenderer.send('dl:remove', id), clear: uid => ipcRenderer.send('dl:clear', uid),
      open: id => ipcRenderer.send('dl:open', id), show: id => ipcRenderer.send('dl:show', id),
      trash: id => ipcRenderer.send('dl:trash', id), folder: () => ipcRenderer.send('dl:folder'),
      retry: id => ipcRenderer.send('dl:retry', id),
      onChange: cb => { const h = () => cb(); ipcRenderer.on('dl:changed', h); return () => ipcRenderer.removeListener('dl:changed', h); }
    }
  });
}
